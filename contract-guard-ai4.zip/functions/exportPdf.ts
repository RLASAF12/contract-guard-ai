import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';
import { jsPDF } from 'npm:jspdf@2.5.2';

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const user = await base44.auth.me();
  if (!user) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const { analysis } = await req.json();
  if (!analysis) {
    return Response.json({ error: 'Missing analysis data' }, { status: 400 });
  }

  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 20;
  const contentWidth = pageWidth - margin * 2;
  let y = 20;

  const checkPage = (needed) => {
    if (y + needed > pageHeight - 20) {
      doc.addPage();
      y = 20;
    }
  };

  const wrapText = (text, maxWidth, fontSize) => {
    doc.setFontSize(fontSize);
    return doc.splitTextToSize(text || '', maxWidth);
  };

  // Header
  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, pageWidth, 40, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('ContractGuard AI', margin, 26);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text('Contract Risk Analysis Report', pageWidth - margin, 26, { align: 'right' });
  y = 55;

  // Title
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  const titleLines = wrapText(analysis.contract_title || 'Untitled Contract', contentWidth, 18);
  doc.text(titleLines, margin, y);
  y += titleLines.length * 8 + 4;

  // Meta
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  const perspLabels = { party_a: 'Party A', party_b: 'Party B', neutral: 'Neutral' };
  doc.text(`Perspective: ${perspLabels[analysis.perspective] || analysis.perspective}  |  Date: ${new Date().toLocaleDateString()}`, margin, y);
  y += 12;

  // Risk badge
  const riskColors = { low: [16, 185, 129], medium: [245, 158, 11], high: [239, 68, 68] };
  const riskLabels = { low: 'LOW RISK', medium: 'MEDIUM RISK', high: 'HIGH RISK' };
  const rc = riskColors[analysis.risk_score] || riskColors.medium;
  doc.setFillColor(rc[0], rc[1], rc[2]);
  doc.roundedRect(margin, y, 50, 10, 2, 2, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text(riskLabels[analysis.risk_score] || 'MEDIUM RISK', margin + 25, y + 7, { align: 'center' });
  y += 20;

  // Executive Summary
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('Executive Summary', margin, y);
  y += 8;
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(71, 85, 105);
  const summaryLines = wrapText(analysis.executive_summary, contentWidth, 10);
  checkPage(summaryLines.length * 5 + 10);
  doc.text(summaryLines, margin, y);
  y += summaryLines.length * 5 + 12;

  // Key Findings
  let findings = [];
  try { findings = JSON.parse(analysis.key_findings) || []; } catch (e) { /* ignore */ }

  if (findings.length > 0) {
    checkPage(20);
    doc.setTextColor(15, 23, 42);
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Key Findings (' + findings.length + ')', margin, y);
    y += 10;

    for (let i = 0; i < findings.length; i++) {
      const f = findings[i];
      checkPage(35);

      doc.setFontSize(10);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(15, 23, 42);
      doc.text((i + 1) + '. ' + (f.title || 'Flagged Clause'), margin, y);
      y += 7;

      if (f.clause_text) {
        doc.setFontSize(9);
        doc.setFont('helvetica', 'italic');
        doc.setTextColor(100, 116, 139);
        const cLines = wrapText('"' + f.clause_text + '"', contentWidth - 10, 9);
        checkPage(cLines.length * 4 + 5);
        doc.text(cLines, margin + 5, y);
        y += cLines.length * 4 + 4;
      }

      if (f.explanation) {
        doc.setFontSize(9);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(71, 85, 105);
        const eLines = wrapText('Risk: ' + f.explanation, contentWidth - 5, 9);
        checkPage(eLines.length * 4 + 5);
        doc.text(eLines, margin + 5, y);
        y += eLines.length * 4 + 3;
      }

      if (f.suggestion) {
        doc.setFontSize(9);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(37, 99, 235);
        const sLines = wrapText('Suggestion: ' + f.suggestion, contentWidth - 5, 9);
        checkPage(sLines.length * 4 + 5);
        doc.text(sLines, margin + 5, y);
        y += sLines.length * 4 + 3;
      }
      y += 6;
    }
  }

  // Missing Protections
  let protections = [];
  try { protections = JSON.parse(analysis.missing_protections) || []; } catch (e) { /* ignore */ }

  if (protections.length > 0) {
    checkPage(20);
    doc.setTextColor(15, 23, 42);
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Missing Protections (' + protections.length + ')', margin, y);
    y += 10;

    for (let i = 0; i < protections.length; i++) {
      const p = protections[i];
      checkPage(20);
      doc.setFontSize(10);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(234, 88, 12);
      doc.text('• ' + p.title, margin + 5, y);
      y += 6;
      if (p.description) {
        doc.setFontSize(9);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(71, 85, 105);
        const dLines = wrapText(p.description, contentWidth - 10, 9);
        checkPage(dLines.length * 4 + 5);
        doc.text(dLines, margin + 10, y);
        y += dLines.length * 4 + 6;
      }
    }
  }

  // Disclaimer
  checkPage(20);
  y += 10;
  doc.setDrawColor(200, 200, 200);
  doc.line(margin, y, pageWidth - margin, y);
  y += 8;
  doc.setFontSize(7);
  doc.setFont('helvetica', 'italic');
  doc.setTextColor(148, 163, 184);
  doc.text('This analysis is AI-generated and is not legal advice. Consult a qualified attorney for legal decisions.', margin, y);

  const pdfBytes = doc.output('arraybuffer');
  const safeName = (analysis.contract_title || 'analysis').replace(/[^a-zA-Z0-9]/g, '_');

  return new Response(pdfBytes, {
    status: 200,
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': 'attachment; filename="' + safeName + '_report.pdf"'
    }
  });
});