import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const user = await base44.auth.me();

  if (user?.role !== 'admin') {
    return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
  }

  // Get all analyses
  const analyses = await base44.asServiceRole.entities.Analysis.filter({});

  if (analyses.length === 0) {
    return Response.json({ message: "No analyses to check", alerts_created: 0 });
  }

  let alertsCreated = 0;

  // Process each analysis - ask AI about regulatory changes
  for (const analysis of analyses) {
    let findings = [];
    try { findings = JSON.parse(analysis.key_findings || "[]"); } catch { continue; }

    if (findings.length === 0) continue;

    const clauseTitles = findings.map(f => f.title).join(", ");

    const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: `You are a legal compliance monitoring AI. Check if there are any recent or well-known regulatory changes, legal updates, or emerging legal trends that might affect the following contract clauses.

Contract: "${analysis.contract_title}"
Perspective: ${analysis.perspective}
Flagged clauses: ${clauseTitles}
Executive summary: ${analysis.executive_summary}

Key clause details:
${findings.map(f => `- ${f.title}: "${f.clause_text}"`).join('\n')}

Determine if ANY of these clauses might now be non-compliant or outdated due to:
- Changes in data protection laws (GDPR updates, CCPA, etc.)
- Employment law changes
- Consumer protection updates
- Industry-specific regulatory changes
- Significant court rulings that changed interpretation

If you find potential compliance issues, list them. If the clauses appear fine, return an empty array.
Be conservative - only flag genuine concerns, not theoretical ones.`,
      response_json_schema: {
        type: "object",
        properties: {
          alerts: {
            type: "array",
            items: {
              type: "object",
              properties: {
                alert_title: { type: "string" },
                description: { type: "string" },
                affected_clauses: {
                  type: "array",
                  items: { type: "string" }
                },
                severity: { type: "string", enum: ["info", "warning", "critical"] },
              },
            },
          },
        },
      },
      add_context_from_internet: true,
    });

    if (result.alerts && result.alerts.length > 0) {
      for (const alert of result.alerts) {
        await base44.asServiceRole.entities.ComplianceAlert.create({
          analysis_id: analysis.id,
          contract_title: analysis.contract_title,
          alert_title: alert.alert_title,
          description: alert.description,
          affected_clauses: JSON.stringify(alert.affected_clauses || []),
          severity: alert.severity || "info",
          is_read: false,
          owner_email: analysis.created_by,
        });
        alertsCreated++;
      }
    }
  }

  return Response.json({
    message: "Compliance check complete",
    analyses_checked: analyses.length,
    alerts_created: alertsCreated,
  });
});