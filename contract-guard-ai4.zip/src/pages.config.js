/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import About from './pages/About';
import Analyze from './pages/Analyze';
import Home from './pages/Home';
import MyAnalyses from './pages/MyAnalyses';
import Results from './pages/Results';
import Compare from './pages/Compare';
import Alerts from './pages/Alerts';
import SharedReport from './pages/SharedReport';
import GenerateContract from './pages/GenerateContract';
import ContractPreview from './pages/ContractPreview';
import ClauseLibrary from './pages/ClauseLibrary';
import Pipeline from './pages/Pipeline';
import Workspaces from './pages/Workspaces';
import WorkspaceDetail from './pages/WorkspaceDetail';
import VisualDiff from './pages/VisualDiff';
import __Layout from './Layout.jsx';


export const PAGES = {
    "About": About,
    "Analyze": Analyze,
    "Home": Home,
    "MyAnalyses": MyAnalyses,
    "Results": Results,
    "Compare": Compare,
    "Alerts": Alerts,
    "SharedReport": SharedReport,
    "GenerateContract": GenerateContract,
    "ContractPreview": ContractPreview,
    "ClauseLibrary": ClauseLibrary,
    "Pipeline": Pipeline,
    "Workspaces": Workspaces,
    "WorkspaceDetail": WorkspaceDetail,
    "VisualDiff": VisualDiff,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
    Layout: __Layout,
};