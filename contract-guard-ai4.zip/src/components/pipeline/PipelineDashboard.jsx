import React from "react";
import { DollarSign, FileText, AlertTriangle, Clock, PenLine } from "lucide-react";
import { motion } from "framer-motion";
import { differenceInDays, parseISO } from "date-fns";

export default function PipelineDashboard({ contracts }) {
  const activeContracts = contracts.filter(c => c.stage !== "executed");
  const totalValue = contracts.reduce((sum, c) => sum + (c.contract_value || 0), 0);
  const activeValue = activeContracts.reduce((sum, c) => sum + (c.contract_value || 0), 0);

  const expiringContracts = contracts.filter(c => {
    if (!c.end_date || c.stage === "executed") return false;
    const days = differenceInDays(parseISO(c.end_date), new Date());
    return days >= 0 && days <= 30;
  });

  const awaitingSignature = contracts.filter(c => c.signature_status === "sent" || c.signature_status === "partially_signed").length;

  const stats = [
    {
      label: "Total Contracts",
      value: contracts.length,
      icon: FileText,
      color: "bg-slate-100 text-slate-600",
    },
    {
      label: "Active Pipeline Value",
      value: activeValue > 0 ? `$${activeValue.toLocaleString()}` : "$0",
      icon: DollarSign,
      color: "bg-emerald-50 text-emerald-600",
    },
    {
      label: "Awaiting Signature",
      value: awaitingSignature,
      icon: PenLine,
      color: awaitingSignature > 0 ? "bg-amber-50 text-amber-600" : "bg-slate-100 text-slate-600",
    },
    {
      label: "Expiring Soon",
      value: expiringContracts.length,
      icon: AlertTriangle,
      color: expiringContracts.length > 0 ? "bg-red-50 text-red-600" : "bg-slate-100 text-slate-600",
    },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {stats.map((stat, i) => (
        <motion.div
          key={stat.label}
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.06 }}
          className="bg-white border border-slate-200 rounded-2xl p-5"
        >
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${stat.color}`}>
            <stat.icon className="w-5 h-5" />
          </div>
          <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
          <p className="text-xs text-slate-500 mt-0.5">{stat.label}</p>
        </motion.div>
      ))}

      {expiringContracts.length > 0 && (
        <div className="col-span-2 lg:col-span-4">
          <div className="bg-red-50 border border-red-200 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-4 h-4 text-red-500" />
              <span className="text-sm font-semibold text-red-700">Upcoming Expirations</span>
            </div>
            <div className="space-y-1">
              {expiringContracts.map(c => {
                const days = differenceInDays(parseISO(c.end_date), new Date());
                return (
                  <p key={c.id} className="text-xs text-red-600">
                    <span className="font-semibold">{c.title}</span> — expires in {days} day{days !== 1 ? "s" : ""}
                  </p>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}