import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { FileText, DollarSign, Calendar, PenLine } from "lucide-react";
import { format, parseISO, differenceInDays } from "date-fns";

const typeLabels = {
  service_agreement: "Service",
  nda: "NDA",
  employment: "Employment",
  freelance: "Freelance",
  lease: "Lease",
  partnership: "Partnership",
  licensing: "Licensing",
  sales: "Sales",
  other: "Other",
};

export default function PipelineCard({ contract, isDragging }) {
  const daysUntilExpiry = contract.end_date
    ? differenceInDays(parseISO(contract.end_date), new Date())
    : null;

  return (
    <Link to={createPageUrl("ContractPreview") + "?id=" + contract.id}>
      <div
        className={`bg-white rounded-xl p-4 border transition-all cursor-pointer hover:shadow-md ${
          isDragging ? "shadow-lg border-slate-400 rotate-2" : "border-slate-200"
        }`}
      >
        <div className="flex items-start gap-3">
          <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-slate-900 flex items-center justify-center">
            <FileText className="w-4 h-4 text-white" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="font-semibold text-sm text-slate-800 truncate">{contract.title}</p>
            <p className="text-xs text-slate-400 mt-0.5">
              {typeLabels[contract.contract_type] || contract.contract_type}
            </p>
          </div>
        </div>
        <div className="mt-3 flex items-center gap-3 flex-wrap">
          {contract.contract_value > 0 && (
            <span className="inline-flex items-center gap-1 text-xs text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
              <DollarSign className="w-3 h-3" />
              {contract.contract_value.toLocaleString()}
            </span>
          )}
          {contract.end_date && (
            <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full ${
              daysUntilExpiry !== null && daysUntilExpiry <= 30 && daysUntilExpiry >= 0
                ? "text-red-600 bg-red-50"
                : "text-slate-500 bg-slate-100"
            }`}>
              <Calendar className="w-3 h-3" />
              {format(parseISO(contract.end_date), "MMM d, yyyy")}
            </span>
          )}
        </div>
        <div className="flex items-center justify-between mt-2">
          <p className="text-xs text-slate-400 truncate">
            {contract.party_a_name} & {contract.party_b_name}
          </p>
          {contract.signature_status && contract.signature_status !== "not_sent" && (
            <span className={`inline-flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.5 rounded-full ${
              contract.signature_status === "completed" ? "bg-emerald-50 text-emerald-600" :
              contract.signature_status === "partially_signed" ? "bg-amber-50 text-amber-600" :
              "bg-blue-50 text-blue-600"
            }`}>
              <PenLine className="w-2.5 h-2.5" />
              {contract.signature_status === "completed" ? "Signed" :
               contract.signature_status === "partially_signed" ? "Partial" : "Sent"}
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}