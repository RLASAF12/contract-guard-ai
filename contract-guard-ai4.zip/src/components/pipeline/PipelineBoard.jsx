import React from "react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import PipelineCard from "./PipelineCard";

const stages = [
  { key: "drafting", label: "Drafting", color: "border-slate-300 bg-slate-50" },
  { key: "in_negotiation", label: "In Negotiation", color: "border-blue-300 bg-blue-50" },
  { key: "pending_signature", label: "Pending Signature", color: "border-amber-300 bg-amber-50" },
  { key: "executed", label: "Executed", color: "border-emerald-300 bg-emerald-50" },
];

export default function PipelineBoard({ contracts, onStageChange }) {
  const handleDragEnd = (result) => {
    if (!result.destination) return;
    const contractId = result.draggableId;
    const newStage = result.destination.droppableId;
    const contract = contracts.find(c => c.id === contractId);
    if (contract && contract.stage !== newStage) {
      onStageChange(contractId, newStage);
    }
  };

  return (
    <DragDropContext onDragEnd={handleDragEnd}>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stages.map((stage) => {
          const stageContracts = contracts.filter(c => c.stage === stage.key);
          return (
            <Droppable key={stage.key} droppableId={stage.key}>
              {(provided, snapshot) => (
                <div
                  ref={provided.innerRef}
                  {...provided.droppableProps}
                  className={`rounded-2xl border-2 border-dashed p-4 min-h-[300px] transition-colors ${
                    snapshot.isDraggingOver ? "bg-slate-100 border-slate-400" : stage.color
                  }`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-sm font-bold text-slate-700">{stage.label}</h3>
                    <span className="text-xs font-semibold bg-white text-slate-500 px-2 py-0.5 rounded-full border border-slate-200">
                      {stageContracts.length}
                    </span>
                  </div>
                  <div className="space-y-3">
                    {stageContracts.map((contract, i) => (
                      <Draggable key={contract.id} draggableId={contract.id} index={i}>
                        {(provided, snapshot) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                          >
                            <PipelineCard contract={contract} isDragging={snapshot.isDragging} />
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                </div>
              )}
            </Droppable>
          );
        })}
      </div>
    </DragDropContext>
  );
}