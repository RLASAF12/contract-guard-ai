import React from "react";
import { format } from "date-fns";
import { FileText, Trash2, Eye, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import RiskBadge from "./RiskBadge";
import { motion } from "framer-motion";

const perspectiveLabels = {
  party_a: "Party A",
  party_b: "Party B",
  neutral: "Neutral",
};

export default function AnalysisCard({ analysis, onView, onDelete, onShare, index }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.06 }}
      className="group bg-white border border-slate-200 rounded-xl p-5 hover:shadow-lg hover:border-slate-300 transition-all duration-300"
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-4 min-w-0">
          <div className="flex-shrink-0 w-11 h-11 rounded-xl bg-slate-900 flex items-center justify-center">
            <FileText className="w-5 h-5 text-white" />
          </div>
          <div className="min-w-0">
            <h3 className="font-semibold text-slate-800 truncate">{analysis.contract_title}</h3>
            <div className="flex flex-wrap items-center gap-2 mt-1.5">
              <RiskBadge level={analysis.risk_score} size="sm" />
              <span className="text-xs text-slate-400">•</span>
              <span className="text-xs text-slate-500">{perspectiveLabels[analysis.perspective]}</span>
              <span className="text-xs text-slate-400">•</span>
              <span className="text-xs text-slate-500">{format(new Date(analysis.created_date), "MMM d, yyyy")}</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1.5 flex-shrink-0">
          <Button variant="ghost" size="icon" onClick={() => onView(analysis)} className="text-slate-400 hover:text-slate-700">
            <Eye className="w-4 h-4" />
          </Button>
          {onShare && (
            <Button variant="ghost" size="icon" onClick={() => onShare(analysis)} className="text-slate-400 hover:text-blue-600">
              <Share2 className="w-4 h-4" />
            </Button>
          )}
          <Button variant="ghost" size="icon" onClick={() => onDelete(analysis)} className="text-slate-400 hover:text-red-600">
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>
      {analysis.executive_summary && (
        <p className="text-sm text-slate-500 mt-3 line-clamp-2 leading-relaxed">{analysis.executive_summary}</p>
      )}
    </motion.div>
  );
}