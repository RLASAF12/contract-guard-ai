import React, { useState } from "react";
import { ChevronDown, ChevronUp, AlertTriangle, Lightbulb, FileText, Scale, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import RiskBadge from "./RiskBadge";
import NegotiationModal from "./NegotiationModal";
import ClauseSwapPicker from "./ClauseSwapPicker";
import { motion, AnimatePresence } from "framer-motion";

export default function FindingCard({ finding, index, perspective }) {
  const [expanded, setExpanded] = useState(false);
  const [showNegotiate, setShowNegotiate] = useState(false);
  const [showClauseSwap, setShowClauseSwap] = useState(false);

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: index * 0.08 }}
        className="border border-slate-200 rounded-xl bg-white overflow-hidden hover:shadow-md transition-shadow"
      >
        <button
          onClick={() => setExpanded(!expanded)}
          className="w-full flex items-center justify-between p-5 text-left"
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center">
              <span className="text-sm font-semibold text-slate-500">{index + 1}</span>
            </div>
            <div className="min-w-0">
              <p className="font-medium text-slate-800 truncate">{finding.title || "Flagged Clause"}</p>
              <div className="mt-1">
                <RiskBadge level={finding.risk_level || "medium"} size="sm" />
              </div>
            </div>
          </div>
          {expanded ? (
            <ChevronUp className="w-5 h-5 text-slate-400 flex-shrink-0" />
          ) : (
            <ChevronDown className="w-5 h-5 text-slate-400 flex-shrink-0" />
          )}
        </button>

        <AnimatePresence>
          {expanded && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden"
            >
              <div className="px-5 pb-5 space-y-4 border-t border-slate-100 pt-4">
                {finding.clause_text && (
                  <div className="bg-slate-50 rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <FileText className="w-4 h-4 text-slate-500" />
                      <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Original Clause</span>
                    </div>
                    <p className="text-sm text-slate-700 italic leading-relaxed">"{finding.clause_text}"</p>
                  </div>
                )}
                {finding.explanation && (
                  <div className="flex gap-3">
                    <AlertTriangle className="w-4 h-4 text-amber-500 mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Why It's Risky</span>
                      <p className="text-sm text-slate-700 mt-1 leading-relaxed">{finding.explanation}</p>
                    </div>
                  </div>
                )}
                {finding.suggestion && (
                  <div className="flex gap-3">
                    <Lightbulb className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Suggested Improvement</span>
                      <p className="text-sm text-slate-700 mt-1 leading-relaxed">{finding.suggestion}</p>
                    </div>
                  </div>
                )}

                {finding.clause_text && (
                  <div className="flex gap-2 flex-wrap">
                    <Button
                      onClick={(e) => { e.stopPropagation(); setShowNegotiate(true); }}
                      variant="outline"
                      size="sm"
                      className="rounded-lg text-xs border-slate-300 hover:bg-slate-50"
                    >
                      <Scale className="w-3.5 h-3.5 mr-1.5" />
                      Negotiate This Clause
                    </Button>
                    <Button
                      onClick={(e) => { e.stopPropagation(); setShowClauseSwap(true); }}
                      variant="outline"
                      size="sm"
                      className="rounded-lg text-xs border-slate-300 hover:bg-slate-50"
                    >
                      <BookOpen className="w-3.5 h-3.5 mr-1.5" />
                      Swap from Library
                    </Button>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      <AnimatePresence>
        {showNegotiate && (
          <NegotiationModal
            finding={finding}
            perspective={perspective}
            onClose={() => setShowNegotiate(false)}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showClauseSwap && (
          <ClauseSwapPicker
            findingTitle={finding.title || "this clause"}
            onClose={() => setShowClauseSwap(false)}
          />
        )}
      </AnimatePresence>
    </>
  );
}