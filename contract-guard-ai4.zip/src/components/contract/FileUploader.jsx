import React, { useRef, useState } from "react";
import { Upload, FileText, X, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";

export default function FileUploader({ onTextExtracted, label }) {
  const fileRef = useRef(null);
  const [fileName, setFileName] = useState("");
  const [extracting, setExtracting] = useState(false);

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    setExtracting(true);

    const { file_url } = await base44.integrations.Core.UploadFile({ file });

    const result = await base44.integrations.Core.ExtractDataFromUploadedFile({
      file_url,
      json_schema: {
        type: "object",
        properties: {
          full_text: {
            type: "string",
            description: "The complete text content of the document, preserving paragraphs and structure"
          }
        }
      }
    });

    if (result.status === "success" && result.output?.full_text) {
      onTextExtracted(result.output.full_text);
    }
    setExtracting(false);
    if (fileRef.current) fileRef.current.value = "";
  };

  const clearFile = () => {
    setFileName("");
    if (fileRef.current) fileRef.current.value = "";
  };

  return (
    <div>
      {label && <p className="text-sm font-medium text-slate-700 mb-2">{label}</p>}
      <div className="border-2 border-dashed border-slate-200 rounded-xl p-6 text-center hover:border-slate-300 transition-colors">
        {extracting ? (
          <div className="flex flex-col items-center gap-2">
            <Loader2 className="w-8 h-8 text-slate-400 animate-spin" />
            <p className="text-sm text-slate-500">Extracting text from <span className="font-medium">{fileName}</span>...</p>
          </div>
        ) : fileName ? (
          <div className="flex items-center justify-center gap-3">
            <FileText className="w-5 h-5 text-slate-500" />
            <span className="text-sm text-slate-700 font-medium">{fileName}</span>
            <button onClick={clearFile} className="p-1 hover:bg-slate-100 rounded-full">
              <X className="w-4 h-4 text-slate-400" />
            </button>
          </div>
        ) : (
          <div>
            <Upload className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <p className="text-sm text-slate-500 mb-1">Upload a PDF or Word document</p>
            <p className="text-xs text-slate-400 mb-3">Text will be extracted automatically</p>
            <Button
              variant="outline"
              size="sm"
              onClick={() => fileRef.current?.click()}
              className="rounded-lg"
            >
              Choose File
            </Button>
          </div>
        )}
        <input
          ref={fileRef}
          type="file"
          accept=".pdf,.doc,.docx"
          onChange={handleFile}
          className="hidden"
        />
      </div>
    </div>
  );
}