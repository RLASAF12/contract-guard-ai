import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { X, BookOpen, ArrowRight, Copy, Check } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const categoryLabels = {
  termination: "Termination",
  liability: "Limitation of Liability",
  indemnification: "Indemnification",
  confidentiality: "Confidentiality",
  ip_ownership: "IP Ownership",
  non_compete: "Non-Compete",
  payment_terms: "Payment Terms",
  dispute_resolution: "Dispute Resolution",
  force_majeure: "Force Majeure",
  data_privacy: "Data Privacy",
  other: "Other",
};

export default function ClauseSwapPicker({ findingTitle, onClose }) {
  const [copiedId, setCopiedId] = useState(null);

  const { data: clauses = [] } = useQuery({
    queryKey: ["saved-clauses-swap"],
    queryFn: () => base44.entities.SavedClause.list("-created_date"),
    initialData: [],
  });

  const handleCopy = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[80vh] flex flex-col"
      >
        <div className="p-6 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Clause Library</h2>
              <p className="text-xs text-slate-500">Pick approved language for "{findingTitle}"</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-lg">
            <X className="w-5 h-5 text-slate-400" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          {clauses.length === 0 ? (
            <div className="text-center py-12">
              <BookOpen className="w-8 h-8 text-slate-300 mx-auto mb-3" />
              <p className="text-sm text-slate-500 mb-1">No saved clauses yet.</p>
              <p className="text-xs text-slate-400">Add clauses in the Clause Library page first.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {clauses.map((clause) => (
                <div key={clause.id} className="border border-slate-200 rounded-xl p-4 hover:border-slate-300 transition-colors">
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <p className="font-medium text-sm text-slate-800">{clause.title}</p>
                      <span className="text-xs text-slate-400">
                        {categoryLabels[clause.category] || clause.category}
                      </span>
                    </div>
                    <Button
                      variant="outline" size="sm"
                      onClick={() => handleCopy(clause.clause_text, clause.id)}
                      className="rounded-lg text-xs"
                    >
                      {copiedId === clause.id ? (
                        <><Check className="w-3 h-3 mr-1" /> Copied</>
                      ) : (
                        <><Copy className="w-3 h-3 mr-1" /> Use This</>
                      )}
                    </Button>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed line-clamp-3">{clause.clause_text}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}