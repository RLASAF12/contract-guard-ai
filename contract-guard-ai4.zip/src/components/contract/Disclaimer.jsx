import React from "react";
import { Info } from "lucide-react";

export default function Disclaimer() {
  return (
    <div className="flex items-start gap-3 bg-slate-50 border border-slate-200 rounded-xl p-4">
      <Info className="w-4 h-4 text-slate-400 mt-0.5 flex-shrink-0" />
      <p className="text-xs text-slate-500 leading-relaxed">
        This analysis is AI-generated and is not legal advice. Consult a qualified attorney for legal decisions.
      </p>
    </div>
  );
}