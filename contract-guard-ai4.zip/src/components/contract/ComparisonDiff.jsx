import React from "react";
import { motion } from "framer-motion";
import { ArrowRight, Plus, Minus, Replace } from "lucide-react";
import RiskBadge from "./RiskBadge";

const typeConfig = {
  added: { icon: Plus, bg: "bg-emerald-50", border: "border-emerald-200", label: "Added", textColor: "text-emerald-700" },
  removed: { icon: Minus, bg: "bg-red-50", border: "border-red-200", label: "Removed", textColor: "text-red-700" },
  modified: { icon: Replace, bg: "bg-blue-50", border: "border-blue-200", label: "Modified", textColor: "text-blue-700" },
};

export default function ComparisonDiff({ change, index }) {
  const cfg = typeConfig[change.change_type] || typeConfig.modified;
  const Icon = cfg.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.06 }}
      className={`${cfg.bg} border ${cfg.border} rounded-xl p-5`}
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-2">
          <Icon className={`w-4 h-4 ${cfg.textColor}`} />
          <span className={`text-xs font-semibold uppercase tracking-wider ${cfg.textColor}`}>{cfg.label}</span>
        </div>
        {change.risk_impact && (
          <RiskBadge level={change.risk_impact} size="sm" />
        )}
      </div>

      <h4 className="font-medium text-slate-800 text-sm mb-2">{change.title}</h4>

      {change.change_type === "modified" && (
        <div className="grid sm:grid-cols-2 gap-3 mb-3">
          <div className="bg-white/60 rounded-lg p-3">
            <p className="text-xs font-semibold text-slate-400 mb-1">Original</p>
            <p className="text-xs text-slate-600 leading-relaxed italic">"{change.old_text}"</p>
          </div>
          <div className="bg-white/60 rounded-lg p-3">
            <div className="flex items-center gap-1 mb-1">
              <ArrowRight className="w-3 h-3 text-slate-400" />
              <p className="text-xs font-semibold text-slate-400">New</p>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed italic">"{change.new_text}"</p>
          </div>
        </div>
      )}

      {(change.change_type === "added" || change.change_type === "removed") && change.clause_text && (
        <div className="bg-white/60 rounded-lg p-3 mb-3">
          <p className="text-xs text-slate-600 leading-relaxed italic">"{change.clause_text}"</p>
        </div>
      )}

      {change.explanation && (
        <p className="text-sm text-slate-600 leading-relaxed">{change.explanation}</p>
      )}
    </motion.div>
  );
}