import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { MessageSquare, Send, User } from "lucide-react";
import { format } from "date-fns";

export default function CommentSection({ analysisId, findingIndex, shareToken }) {
  const queryClient = useQueryClient();
  const [text, setText] = useState("");
  const [authorName, setAuthorName] = useState("");
  const [showForm, setShowForm] = useState(false);

  const queryKey = ["comments", analysisId, findingIndex];

  const { data: comments = [] } = useQuery({
    queryKey,
    queryFn: () => base44.entities.Comment.filter({
      analysis_id: analysisId,
      finding_index: findingIndex,
    }, "-created_date"),
    initialData: [],
  });

  const addComment = useMutation({
    mutationFn: (data) => base44.entities.Comment.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey });
      setText("");
      setShowForm(false);
    },
  });

  const handleSubmit = () => {
    if (!text.trim() || !authorName.trim()) return;
    addComment.mutate({
      analysis_id: analysisId,
      finding_index: findingIndex,
      author_name: authorName,
      text: text.trim(),
      share_token: shareToken,
    });
  };

  return (
    <div className="mt-3 pt-3 border-t border-slate-100">
      <div className="flex items-center gap-2 mb-2">
        <MessageSquare className="w-3.5 h-3.5 text-slate-400" />
        <span className="text-xs font-semibold text-slate-500">
          Comments {comments.length > 0 && `(${comments.length})`}
        </span>
        {!showForm && (
          <button
            onClick={() => setShowForm(true)}
            className="text-xs text-blue-600 hover:text-blue-700 font-medium ml-auto"
          >
            Add Comment
          </button>
        )}
      </div>

      {comments.map((c) => (
        <div key={c.id} className="bg-slate-50 rounded-lg p-3 mb-2">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-5 h-5 rounded-full bg-slate-200 flex items-center justify-center">
              <User className="w-3 h-3 text-slate-500" />
            </div>
            <span className="text-xs font-semibold text-slate-700">{c.author_name}</span>
            <span className="text-xs text-slate-400">
              {format(new Date(c.created_date), "MMM d, h:mm a")}
            </span>
          </div>
          <p className="text-sm text-slate-600 leading-relaxed">{c.text}</p>
        </div>
      ))}

      {showForm && (
        <div className="space-y-2 mt-2">
          <Input
            placeholder="Your name"
            value={authorName}
            onChange={(e) => setAuthorName(e.target.value)}
            className="h-9 text-sm rounded-lg border-slate-200"
          />
          <Textarea
            placeholder="Add a comment..."
            value={text}
            onChange={(e) => setText(e.target.value)}
            className="min-h-[60px] text-sm rounded-lg border-slate-200"
          />
          <div className="flex gap-2 justify-end">
            <Button variant="ghost" size="sm" onClick={() => setShowForm(false)} className="text-xs">
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={handleSubmit}
              disabled={!text.trim() || !authorName.trim()}
              className="bg-slate-900 hover:bg-slate-800 text-xs rounded-lg"
            >
              <Send className="w-3 h-3 mr-1.5" /> Post
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}