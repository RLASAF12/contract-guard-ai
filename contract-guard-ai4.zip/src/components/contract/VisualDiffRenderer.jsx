import React from "react";
import { motion } from "framer-motion";
import RiskBadge from "./RiskBadge";
import { Plus, Minus, ArrowLeftRight } from "lucide-react";

const typeStyles = {
  added: {
    bg: "bg-emerald-50",
    border: "border-l-emerald-500",
    textBg: "bg-emerald-100",
    icon: Plus,
    label: "ADDED",
    labelColor: "text-emerald-700",
  },
  removed: {
    bg: "bg-red-50",
    border: "border-l-red-500",
    textBg: "bg-red-100 line-through decoration-red-400",
    icon: Minus,
    label: "REMOVED",
    labelColor: "text-red-700",
  },
  modified: {
    bg: "bg-blue-50",
    border: "border-l-blue-500",
    textBg: "",
    icon: ArrowLeftRight,
    label: "MODIFIED",
    labelColor: "text-blue-700",
  },
};

export default function VisualDiffRenderer({ changes }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white border border-slate-200 rounded-2xl overflow-hidden"
    >
      <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
        <h3 className="font-semibold text-sm text-slate-700">Visual Diff — Color-Coded Changes</h3>
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5 text-xs text-emerald-600"><span className="w-3 h-3 rounded bg-emerald-200" /> Additions</span>
          <span className="flex items-center gap-1.5 text-xs text-red-600"><span className="w-3 h-3 rounded bg-red-200" /> Removals</span>
          <span className="flex items-center gap-1.5 text-xs text-blue-600"><span className="w-3 h-3 rounded bg-blue-200" /> Modifications</span>
        </div>
      </div>

      <div className="divide-y divide-slate-100">
        {changes.map((change, i) => {
          const style = typeStyles[change.change_type] || typeStyles.modified;
          const Icon = style.icon;

          return (
            <motion.div
              key={i}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: i * 0.04 }}
              className={`${style.bg} border-l-4 ${style.border} p-5`}
            >
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="flex items-center gap-2">
                  <Icon className={`w-4 h-4 ${style.labelColor}`} />
                  <span className={`text-xs font-bold uppercase tracking-wider ${style.labelColor}`}>{style.label}</span>
                  <span className="text-xs text-slate-500">— {change.section_title}</span>
                </div>
                <RiskBadge level={change.risk_impact} size="sm" />
              </div>

              {change.change_type === "modified" ? (
                <div className="space-y-2">
                  <div className="rounded-lg p-3 bg-red-50 border border-red-100">
                    <p className="text-xs font-semibold text-red-400 mb-1">— Original</p>
                    <p className="text-sm text-slate-700 leading-relaxed line-through decoration-red-300 decoration-2">
                      {change.original_text}
                    </p>
                  </div>
                  <div className="rounded-lg p-3 bg-emerald-50 border border-emerald-100">
                    <p className="text-xs font-semibold text-emerald-400 mb-1">+ Revised</p>
                    <p className="text-sm text-slate-700 leading-relaxed">
                      {change.revised_text}
                    </p>
                  </div>
                </div>
              ) : change.change_type === "added" ? (
                <div className="rounded-lg p-3 bg-emerald-100/50 border border-emerald-200">
                  <p className="text-sm text-slate-700 leading-relaxed">
                    {change.revised_text}
                  </p>
                </div>
              ) : (
                <div className="rounded-lg p-3 bg-red-100/50 border border-red-200">
                  <p className="text-sm text-slate-700 leading-relaxed line-through decoration-red-400 decoration-2">
                    {change.original_text}
                  </p>
                </div>
              )}

              <p className="text-xs text-slate-500 mt-3 leading-relaxed italic">{change.explanation}</p>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
}