import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { X, Link2, Copy, Check, Loader2 } from "lucide-react";
import { motion } from "framer-motion";

export default function ShareModal({ analysis, onClose, onTokenGenerated }) {
  const [shareUrl, setShareUrl] = useState("");
  const [generating, setGenerating] = useState(false);
  const [copied, setCopied] = useState(false);

  const generateShareLink = async () => {
    setGenerating(true);
    let token = analysis.share_token;
    if (!token) {
      token = Math.random().toString(36).substring(2) + Date.now().toString(36);
      await base44.entities.Analysis.update(analysis.id, { share_token: token });
      if (onTokenGenerated) onTokenGenerated(token);
    }
    const url = window.location.origin + "/SharedReport?token=" + token;
    setShareUrl(url);
    setGenerating(false);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="bg-white rounded-2xl shadow-2xl w-full max-w-md"
      >
        <div className="p-6 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center">
              <Link2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Share Report</h2>
              <p className="text-xs text-slate-500">Generate a link for team members or counsel</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-lg">
            <X className="w-5 h-5 text-slate-400" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <p className="text-sm text-slate-600">
            Anyone with the link can view this analysis and add comments on specific findings.
          </p>

          {!shareUrl ? (
            <Button
              onClick={generateShareLink}
              disabled={generating}
              className="w-full h-12 bg-slate-900 hover:bg-slate-800 rounded-xl font-semibold"
            >
              {generating ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Generating...</>
              ) : (
                <><Link2 className="w-4 h-4 mr-2" /> Generate Share Link</>
              )}
            </Button>
          ) : (
            <div className="space-y-3">
              <div className="flex gap-2">
                <Input
                  value={shareUrl}
                  readOnly
                  className="rounded-xl border-slate-200 text-sm bg-slate-50"
                />
                <Button
                  onClick={handleCopy}
                  variant="outline"
                  className="rounded-xl px-4 flex-shrink-0"
                >
                  {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
              <p className="text-xs text-slate-400">
                Collaborators can comment on specific clauses. Comments are visible to everyone with the link.
              </p>
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}