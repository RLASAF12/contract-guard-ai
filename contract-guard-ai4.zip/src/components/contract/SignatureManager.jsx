import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X, Plus, Send, Loader2, PenLine, Check, Clock, Mail, User } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const statusConfig = {
  pending: { label: "Pending", icon: Clock, color: "text-amber-600 bg-amber-50" },
  signed: { label: "Signed", icon: Check, color: "text-emerald-600 bg-emerald-50" },
  declined: { label: "Declined", icon: X, color: "text-red-600 bg-red-50" },
};

export default function SignatureManager({ contract, onUpdate }) {
  const [showAdd, setShowAdd] = useState(false);
  const [sending, setSending] = useState(false);
  const [newSigner, setNewSigner] = useState({ name: "", email: "", role: "signer" });

  const signers = (() => {
    try { return JSON.parse(contract.signers || "[]"); } catch { return []; }
  })();

  const handleAddSigner = () => {
    if (!newSigner.name.trim() || !newSigner.email.trim()) return;
    const updated = [...signers, { ...newSigner, status: "pending" }];
    base44.entities.Contract.update(contract.id, { signers: JSON.stringify(updated) });
    onUpdate({ signers: JSON.stringify(updated) });
    setNewSigner({ name: "", email: "", role: "signer" });
    setShowAdd(false);
  };

  const handleRemoveSigner = (index) => {
    const updated = signers.filter((_, i) => i !== index);
    base44.entities.Contract.update(contract.id, { signers: JSON.stringify(updated) });
    onUpdate({ signers: JSON.stringify(updated) });
  };

  const handleSendForSignature = async () => {
    if (signers.length === 0) return;
    setSending(true);

    for (const signer of signers) {
      await base44.integrations.Core.SendEmail({
        to: signer.email,
        subject: `Signature Request: ${contract.title}`,
        body: `<div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2 style="color: #0f172a;">Signature Request</h2>
          <p>Hello ${signer.name},</p>
          <p>You have been asked to review and sign the following contract:</p>
          <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px; margin: 16px 0;">
            <p style="margin: 0; font-weight: 600;">${contract.title}</p>
            <p style="margin: 4px 0 0; color: #64748b; font-size: 14px;">${contract.party_a_name} & ${contract.party_b_name}</p>
          </div>
          <p>Your role: <strong>${signer.role === "signer" ? "Signer" : "Witness"}</strong></p>
          <p style="color: #64748b; font-size: 13px;">Please review the contract and provide your signature. The contract owner will be notified once you sign.</p>
          <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 20px 0;" />
          <p style="color: #94a3b8; font-size: 12px;">Sent via ContractGuard AI</p>
        </div>`,
      });
    }

    await base44.entities.Contract.update(contract.id, {
      signature_status: "sent",
      signature_sent_date: new Date().toISOString(),
      stage: "pending_signature",
    });
    onUpdate({ signature_status: "sent", signature_sent_date: new Date().toISOString(), stage: "pending_signature" });
    setSending(false);
  };

  const handleToggleSign = async (index) => {
    const updated = [...signers];
    updated[index].status = updated[index].status === "signed" ? "pending" : "signed";
    const allSigned = updated.every(s => s.status === "signed");
    const someSigned = updated.some(s => s.status === "signed");
    const newSigStatus = allSigned ? "completed" : someSigned ? "partially_signed" : "sent";
    const newStage = allSigned ? "executed" : contract.stage;

    await base44.entities.Contract.update(contract.id, {
      signers: JSON.stringify(updated),
      signature_status: newSigStatus,
      stage: newStage,
    });
    onUpdate({ signers: JSON.stringify(updated), signature_status: newSigStatus, stage: newStage });
  };

  const signatureStatus = contract.signature_status || "not_sent";

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8"
    >
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center">
            <PenLine className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900">E-Signature</h3>
            <p className="text-xs text-slate-500">
              {signatureStatus === "not_sent" && "Add signers and send for signature"}
              {signatureStatus === "sent" && "Waiting for signatures"}
              {signatureStatus === "partially_signed" && "Some parties have signed"}
              {signatureStatus === "completed" && "All parties have signed"}
            </p>
          </div>
        </div>
        {signatureStatus !== "not_sent" && (
          <span className={`text-xs font-semibold px-3 py-1 rounded-full ${
            signatureStatus === "completed" ? "bg-emerald-50 text-emerald-700" :
            signatureStatus === "partially_signed" ? "bg-amber-50 text-amber-700" :
            "bg-blue-50 text-blue-700"
          }`}>
            {signatureStatus === "completed" ? "Completed" :
             signatureStatus === "partially_signed" ? "Partially Signed" : "Sent"}
          </span>
        )}
      </div>

      {/* Signers List */}
      <div className="space-y-2 mb-4">
        {signers.length === 0 ? (
          <p className="text-sm text-slate-400 py-4 text-center">No signers added yet.</p>
        ) : (
          signers.map((signer, i) => {
            const cfg = statusConfig[signer.status] || statusConfig.pending;
            const StatusIcon = cfg.icon;
            return (
              <div key={i} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center">
                    <User className="w-4 h-4 text-slate-500" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-800">{signer.name}</p>
                    <p className="text-xs text-slate-400">{signer.email} • {signer.role === "witness" ? "Witness" : "Signer"}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full ${cfg.color}`}>
                    <StatusIcon className="w-3 h-3" />
                    {cfg.label}
                  </span>
                  {signatureStatus !== "not_sent" && signer.status !== "signed" && (
                    <Button variant="ghost" size="sm" onClick={() => handleToggleSign(i)} className="text-xs text-emerald-600 hover:text-emerald-700">
                      Mark Signed
                    </Button>
                  )}
                  {signatureStatus === "not_sent" && (
                    <Button variant="ghost" size="icon" onClick={() => handleRemoveSigner(i)} className="text-slate-400 hover:text-red-500 h-7 w-7">
                      <X className="w-3.5 h-3.5" />
                    </Button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Add Signer */}
      {signatureStatus === "not_sent" && (
        <>
          <AnimatePresence>
            {showAdd && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden mb-4"
              >
                <div className="bg-slate-50 rounded-xl p-4 space-y-3">
                  <div className="grid sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <Label className="text-xs text-slate-600">Name</Label>
                      <Input
                        placeholder="Full name"
                        value={newSigner.name}
                        onChange={(e) => setNewSigner(p => ({ ...p, name: e.target.value }))}
                        className="h-9 rounded-lg border-slate-200 text-sm"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs text-slate-600">Email</Label>
                      <Input
                        type="email"
                        placeholder="email@example.com"
                        value={newSigner.email}
                        onChange={(e) => setNewSigner(p => ({ ...p, email: e.target.value }))}
                        className="h-9 rounded-lg border-slate-200 text-sm"
                      />
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Select value={newSigner.role} onValueChange={(v) => setNewSigner(p => ({ ...p, role: v }))}>
                      <SelectTrigger className="w-32 h-9 rounded-lg border-slate-200 text-sm">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="signer">Signer</SelectItem>
                        <SelectItem value="witness">Witness</SelectItem>
                      </SelectContent>
                    </Select>
                    <div className="flex gap-2 ml-auto">
                      <Button variant="ghost" size="sm" onClick={() => setShowAdd(false)} className="text-xs">Cancel</Button>
                      <Button size="sm" onClick={handleAddSigner} disabled={!newSigner.name.trim() || !newSigner.email.trim()} className="bg-slate-900 hover:bg-slate-800 text-xs rounded-lg">
                        Add
                      </Button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setShowAdd(true)} className="rounded-xl text-sm">
              <Plus className="w-4 h-4 mr-1.5" /> Add Signer
            </Button>
            {signers.length > 0 && (
              <Button
                onClick={handleSendForSignature}
                disabled={sending}
                className="rounded-xl bg-slate-900 hover:bg-slate-800 text-sm"
              >
                {sending ? <Loader2 className="w-4 h-4 mr-1.5 animate-spin" /> : <Send className="w-4 h-4 mr-1.5" />}
                {sending ? "Sending..." : "Send for Signature"}
              </Button>
            )}
          </div>
        </>
      )}
    </motion.div>
  );
}