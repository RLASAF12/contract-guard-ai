import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Bell } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function AlertBadge() {
  const { data: alerts = [] } = useQuery({
    queryKey: ["unread-alerts"],
    queryFn: async () => {
      const all = await base44.entities.ComplianceAlert.filter({ is_read: false }, "-created_date", 50);
      return all;
    },
    initialData: [],
    refetchInterval: 60000,
  });

  const unreadCount = alerts.length;

  return (
    <Link
      to={createPageUrl("Alerts")}
      className="relative p-2 rounded-lg hover:bg-slate-100 transition-colors"
    >
      <Bell className="w-5 h-5 text-slate-500" />
      {unreadCount > 0 && (
        <span className="absolute -top-0.5 -right-0.5 w-5 h-5 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
          {unreadCount > 9 ? "9+" : unreadCount}
        </span>
      )}
    </Link>
  );
}