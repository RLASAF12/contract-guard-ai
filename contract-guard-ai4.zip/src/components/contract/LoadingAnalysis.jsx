import React from "react";
import { motion } from "framer-motion";
import { Shield } from "lucide-react";

export default function LoadingAnalysis() {
  return (
    <div className="flex flex-col items-center justify-center py-24">
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
        className="w-16 h-16 rounded-2xl bg-slate-900 flex items-center justify-center mb-6"
      >
        <Shield className="w-8 h-8 text-white" />
      </motion.div>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        <h3 className="text-xl font-semibold text-slate-800 mb-2">Analyzing your contract...</h3>
        <p className="text-slate-500 text-center max-w-sm">
          Our AI is reviewing every clause for potential risks and missing protections. This may take a moment.
        </p>
      </motion.div>
      <div className="flex gap-1.5 mt-8">
        {[0, 1, 2].map((i) => (
          <motion.div
            key={i}
            className="w-2.5 h-2.5 rounded-full bg-slate-300"
            animate={{ backgroundColor: ["#cbd5e1", "#0f172a", "#cbd5e1"] }}
            transition={{ duration: 1.2, repeat: Infinity, delay: i * 0.2 }}
          />
        ))}
      </div>
    </div>
  );
}