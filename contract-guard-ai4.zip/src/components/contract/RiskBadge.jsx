import React from "react";
import { Shield, ShieldAlert, ShieldCheck } from "lucide-react";

const config = {
  low: {
    label: "Low Risk",
    icon: ShieldCheck,
    bg: "bg-emerald-50",
    border: "border-emerald-200",
    text: "text-emerald-700",
    iconColor: "text-emerald-500",
  },
  medium: {
    label: "Medium Risk",
    icon: Shield,
    bg: "bg-amber-50",
    border: "border-amber-200",
    text: "text-amber-700",
    iconColor: "text-amber-500",
  },
  high: {
    label: "High Risk",
    icon: ShieldAlert,
    bg: "bg-red-50",
    border: "border-red-200",
    text: "text-red-700",
    iconColor: "text-red-500",
  },
};

export default function RiskBadge({ level, size = "md" }) {
  const c = config[level] || config.medium;
  const Icon = c.icon;
  const sizeClasses = size === "lg"
    ? "px-5 py-2.5 text-base gap-2.5"
    : size === "sm"
    ? "px-2.5 py-1 text-xs gap-1.5"
    : "px-3.5 py-1.5 text-sm gap-2";
  const iconSize = size === "lg" ? "w-5 h-5" : size === "sm" ? "w-3.5 h-3.5" : "w-4 h-4";

  return (
    <span className={`inline-flex items-center font-semibold rounded-full border ${c.bg} ${c.border} ${c.text} ${sizeClasses}`}>
      <Icon className={`${iconSize} ${c.iconColor}`} />
      {c.label}
    </span>
  );
}