import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { X, Loader2, Scale, Copy, Check } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import RiskBadge from "./RiskBadge";

export default function NegotiationModal({ finding, perspective, onClose }) {
  const [goals, setGoals] = useState("");
  const [loading, setLoading] = useState(false);
  const [proposals, setProposals] = useState(null);
  const [copiedIndex, setCopiedIndex] = useState(null);

  const perspectiveLabel =
    perspective === "party_a" ? "Party A (offering)" :
    perspective === "party_b" ? "Party B (receiving)" : "a neutral party";

  const handleGenerate = async () => {
    setLoading(true);
    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an expert contract negotiation advisor. A user reviewing a contract as ${perspectiveLabel} has flagged this clause as risky:

Clause: "${finding.clause_text}"
Risk: ${finding.explanation}
Current suggestion: ${finding.suggestion}

The user's negotiation goals: ${goals || "Protect my interests while maintaining a fair agreement."}

Generate 3 counter-proposal options, ranging from conservative to aggressive:
1. Conservative — minimal changes, easy for counterparty to accept
2. Balanced — fair middle ground protecting key interests  
3. Aggressive — maximum protection for the user's position

For each, provide:
- A label (Conservative/Balanced/Aggressive)
- The proposed replacement clause text
- A brief rationale explaining why the counterparty might accept it
- The resulting risk level for the user`,
      response_json_schema: {
        type: "object",
        properties: {
          proposals: {
            type: "array",
            items: {
              type: "object",
              properties: {
                label: { type: "string" },
                clause_text: { type: "string" },
                rationale: { type: "string" },
                risk_level: { type: "string", enum: ["low", "medium", "high"] },
              },
            },
          },
        },
      },
    });
    setProposals(result.proposals || []);
    setLoading(false);
  };

  const handleCopy = (text, idx) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const tierColors = {
    Conservative: "border-emerald-200 bg-emerald-50/50",
    Balanced: "border-blue-200 bg-blue-50/50",
    Aggressive: "border-amber-200 bg-amber-50/50",
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
      >
        <div className="sticky top-0 bg-white border-b border-slate-200 p-6 flex items-center justify-between rounded-t-2xl z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center">
              <Scale className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Negotiation Mode</h2>
              <p className="text-xs text-slate-500">Generate counter-proposals for this clause</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-lg">
            <X className="w-5 h-5 text-slate-400" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {/* Original clause */}
          <div className="bg-red-50/50 border border-red-100 rounded-xl p-4">
            <p className="text-xs font-semibold uppercase tracking-wider text-red-400 mb-1.5">Risky Clause</p>
            <p className="text-sm text-slate-700 italic leading-relaxed">"{finding.clause_text}"</p>
          </div>

          {!proposals && (
            <>
              <div className="space-y-2">
                <Label className="text-sm font-medium text-slate-700">
                  Your Goals (optional)
                </Label>
                <Textarea
                  placeholder="e.g., I want to limit liability to the contract value, keep termination rights flexible, and ensure IP stays with me..."
                  value={goals}
                  onChange={(e) => setGoals(e.target.value)}
                  className="min-h-[100px] rounded-xl border-slate-200 text-sm"
                />
                <p className="text-xs text-slate-400">
                  Describe what you want to achieve — the AI will tailor proposals to your specific needs.
                </p>
              </div>

              <Button
                onClick={handleGenerate}
                disabled={loading}
                className="w-full h-12 bg-slate-900 hover:bg-slate-800 rounded-xl font-semibold"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating counter-proposals...
                  </>
                ) : (
                  <>
                    <Scale className="w-4 h-4 mr-2" />
                    Generate Counter-Proposals
                  </>
                )}
              </Button>
            </>
          )}

          {proposals && (
            <div className="space-y-4">
              <p className="text-sm font-semibold text-slate-700">Choose a counter-proposal:</p>
              {proposals.map((p, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className={`border rounded-xl p-5 ${tierColors[p.label] || "border-slate-200 bg-slate-50/50"}`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-bold text-slate-800">{p.label}</span>
                    <RiskBadge level={p.risk_level} size="sm" />
                  </div>
                  <div className="bg-white rounded-lg p-3 mb-3 border border-slate-100">
                    <p className="text-sm text-slate-800 leading-relaxed">{p.clause_text}</p>
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed mb-3">
                    <span className="font-semibold">Why they'd accept: </span>{p.rationale}
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleCopy(p.clause_text, i)}
                    className="rounded-lg text-xs"
                  >
                    {copiedIndex === i ? (
                      <><Check className="w-3 h-3 mr-1.5" /> Copied</>
                    ) : (
                      <><Copy className="w-3 h-3 mr-1.5" /> Copy Clause</>
                    )}
                  </Button>
                </motion.div>
              ))}
              <Button
                variant="outline"
                onClick={() => { setProposals(null); setGoals(""); }}
                className="w-full rounded-xl"
              >
                Regenerate with different goals
              </Button>
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}