import React from "react";
import { ShieldOff } from "lucide-react";
import { motion } from "framer-motion";

export default function MissingProtectionCard({ protection, index }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.08 }}
      className="flex gap-4 p-4 bg-orange-50/60 border border-orange-100 rounded-xl"
    >
      <div className="flex-shrink-0 w-9 h-9 rounded-full bg-orange-100 flex items-center justify-center">
        <ShieldOff className="w-4 h-4 text-orange-600" />
      </div>
      <div>
        <p className="font-medium text-slate-800 text-sm">{protection.title}</p>
        {protection.description && (
          <p className="text-sm text-slate-600 mt-1 leading-relaxed">{protection.description}</p>
        )}
      </div>
    </motion.div>
  );
}