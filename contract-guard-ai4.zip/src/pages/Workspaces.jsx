import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, FolderOpen, Trash2, Users, X } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { motion, AnimatePresence } from "framer-motion";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const colorConfig = {
  slate: "bg-slate-100 border-slate-300 text-slate-700",
  blue: "bg-blue-100 border-blue-300 text-blue-700",
  emerald: "bg-emerald-100 border-emerald-300 text-emerald-700",
  purple: "bg-purple-100 border-purple-300 text-purple-700",
  amber: "bg-amber-100 border-amber-300 text-amber-700",
  rose: "bg-rose-100 border-rose-300 text-rose-700",
};

const colorDots = {
  slate: "bg-slate-500",
  blue: "bg-blue-500",
  emerald: "bg-emerald-500",
  purple: "bg-purple-500",
  amber: "bg-amber-500",
  rose: "bg-rose-500",
};

export default function Workspaces() {
  const queryClient = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", description: "", color: "slate" });
  const [deleteTarget, setDeleteTarget] = useState(null);

  const { data: workspaces = [], isLoading } = useQuery({
    queryKey: ["workspaces"],
    queryFn: () => base44.entities.Workspace.list("-created_date"),
    initialData: [],
  });

  const { data: contracts = [] } = useQuery({
    queryKey: ["contracts-ws"],
    queryFn: () => base44.entities.Contract.list("-created_date"),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: async (data) => {
      const user = await base44.auth.me();
      return base44.entities.Workspace.create({ ...data, owner_email: user.email, members: "[]" });
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["workspaces"] }); setShowForm(false); setForm({ name: "", description: "", color: "slate" }); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Workspace.delete(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["workspaces"] }); setDeleteTarget(null); },
  });

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-12 sm:py-16">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-10">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Workspaces</h1>
          <p className="mt-1 text-slate-500">Group related contracts by project or client.</p>
        </div>
        <Button onClick={() => setShowForm(true)} className="bg-slate-900 hover:bg-slate-800 rounded-xl h-11 px-5 font-semibold">
          <Plus className="w-4 h-4 mr-2" /> New Workspace
        </Button>
      </div>

      <AnimatePresence>
        {showForm && (
          <motion.div initial={{ opacity: 0, y: -16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }} className="bg-white border border-slate-200 rounded-2xl p-6 mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-slate-900">Create Workspace</h2>
              <button onClick={() => setShowForm(false)} className="p-2 hover:bg-slate-100 rounded-lg"><X className="w-4 h-4 text-slate-400" /></button>
            </div>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium text-slate-700">Name *</Label>
                <Input placeholder="e.g., Acme Corp Deal" value={form.name} onChange={(e) => setForm(p => ({ ...p, name: e.target.value }))} className="h-11 rounded-xl border-slate-200" />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium text-slate-700">Description</Label>
                <Textarea placeholder="Optional description..." value={form.description} onChange={(e) => setForm(p => ({ ...p, description: e.target.value }))} className="min-h-[80px] rounded-xl border-slate-200 text-sm" />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium text-slate-700">Color</Label>
                <div className="flex gap-2">
                  {Object.entries(colorDots).map(([key, cls]) => (
                    <button key={key} onClick={() => setForm(p => ({ ...p, color: key }))} className={`w-8 h-8 rounded-full ${cls} ${form.color === key ? "ring-2 ring-offset-2 ring-slate-400" : ""}`} />
                  ))}
                </div>
              </div>
              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={() => setShowForm(false)} className="rounded-xl">Cancel</Button>
                <Button onClick={() => createMutation.mutate(form)} disabled={!form.name.trim()} className="bg-slate-900 hover:bg-slate-800 rounded-xl font-semibold">Create</Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {isLoading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{[1, 2, 3].map(i => <Skeleton key={i} className="h-40 rounded-2xl" />)}</div>
      ) : workspaces.length === 0 ? (
        <div className="text-center py-24">
          <div className="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center mx-auto mb-5"><FolderOpen className="w-7 h-7 text-slate-400" /></div>
          <h3 className="text-lg font-semibold text-slate-800 mb-2">No workspaces yet</h3>
          <p className="text-slate-500 max-w-sm mx-auto">Create a workspace to group related contracts together.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {workspaces.map((ws, i) => {
            const wsContracts = contracts.filter(c => c.workspace_id === ws.id);
            const members = (() => { try { return JSON.parse(ws.members || "[]"); } catch { return []; } })();
            return (
              <motion.div key={ws.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                <Link to={createPageUrl("WorkspaceDetail") + "?id=" + ws.id}>
                  <div className={`border rounded-2xl p-6 hover:shadow-lg transition-all cursor-pointer ${colorConfig[ws.color] || colorConfig.slate}`}>
                    <div className="flex items-start justify-between mb-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${colorDots[ws.color]} bg-opacity-20`}>
                        <FolderOpen className="w-5 h-5" />
                      </div>
                      <Button variant="ghost" size="icon" onClick={(e) => { e.preventDefault(); e.stopPropagation(); setDeleteTarget(ws); }} className="text-slate-400 hover:text-red-600 h-8 w-8">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                    <h3 className="font-bold text-slate-900 mb-1">{ws.name}</h3>
                    {ws.description && <p className="text-xs text-slate-500 line-clamp-2 mb-3">{ws.description}</p>}
                    <div className="flex items-center gap-3 mt-auto">
                      <span className="text-xs text-slate-500">{wsContracts.length} contract{wsContracts.length !== 1 ? "s" : ""}</span>
                      {members.length > 0 && (
                        <span className="inline-flex items-center gap-1 text-xs text-slate-500"><Users className="w-3 h-3" />{members.length}</span>
                      )}
                    </div>
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </div>
      )}

      <AlertDialog open={!!deleteTarget} onOpenChange={() => setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete workspace?</AlertDialogTitle>
            <AlertDialogDescription>This will permanently delete "{deleteTarget?.name}". Contracts won't be deleted but will be unlinked.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteMutation.mutate(deleteTarget.id)} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}