import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, BookOpen, Trash2, Search, Copy, Check, Pencil, X } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { motion, AnimatePresence } from "framer-motion";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const categoryLabels = {
  termination: "Termination",
  liability: "Limitation of Liability",
  indemnification: "Indemnification",
  confidentiality: "Confidentiality",
  ip_ownership: "IP Ownership",
  non_compete: "Non-Compete",
  payment_terms: "Payment Terms",
  dispute_resolution: "Dispute Resolution",
  force_majeure: "Force Majeure",
  data_privacy: "Data Privacy",
  other: "Other",
};

const categoryColors = {
  termination: "bg-red-50 text-red-700 border-red-200",
  liability: "bg-amber-50 text-amber-700 border-amber-200",
  indemnification: "bg-orange-50 text-orange-700 border-orange-200",
  confidentiality: "bg-purple-50 text-purple-700 border-purple-200",
  ip_ownership: "bg-blue-50 text-blue-700 border-blue-200",
  non_compete: "bg-pink-50 text-pink-700 border-pink-200",
  payment_terms: "bg-emerald-50 text-emerald-700 border-emerald-200",
  dispute_resolution: "bg-indigo-50 text-indigo-700 border-indigo-200",
  force_majeure: "bg-slate-100 text-slate-700 border-slate-200",
  data_privacy: "bg-cyan-50 text-cyan-700 border-cyan-200",
  other: "bg-gray-50 text-gray-700 border-gray-200",
};

export default function ClauseLibrary() {
  const queryClient = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [editingClause, setEditingClause] = useState(null);
  const [search, setSearch] = useState("");
  const [filterCat, setFilterCat] = useState("all");
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [copiedId, setCopiedId] = useState(null);

  const [form, setForm] = useState({ title: "", category: "", clause_text: "", notes: "" });

  const { data: clauses = [], isLoading } = useQuery({
    queryKey: ["saved-clauses"],
    queryFn: () => base44.entities.SavedClause.list("-created_date"),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.SavedClause.create(data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["saved-clauses"] }); resetForm(); },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.SavedClause.update(id, data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["saved-clauses"] }); resetForm(); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.SavedClause.delete(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["saved-clauses"] }); setDeleteTarget(null); },
  });

  const resetForm = () => {
    setForm({ title: "", category: "", clause_text: "", notes: "" });
    setShowForm(false);
    setEditingClause(null);
  };

  const handleEdit = (clause) => {
    setEditingClause(clause);
    setForm({ title: clause.title, category: clause.category, clause_text: clause.clause_text, notes: clause.notes || "" });
    setShowForm(true);
  };

  const handleSubmit = () => {
    if (!form.title.trim() || !form.category || !form.clause_text.trim()) return;
    if (editingClause) {
      updateMutation.mutate({ id: editingClause.id, data: form });
    } else {
      createMutation.mutate(form);
    }
  };

  const handleCopy = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const filtered = clauses.filter(c => {
    const matchSearch = !search || c.title.toLowerCase().includes(search.toLowerCase()) || c.clause_text.toLowerCase().includes(search.toLowerCase());
    const matchCat = filterCat === "all" || c.category === filterCat;
    return matchSearch && matchCat;
  });

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-12 sm:py-16">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-10">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Clause Library</h1>
          <p className="mt-1 text-slate-500">Save and reuse your pre-approved contract language.</p>
        </div>
        <Button
          onClick={() => { resetForm(); setShowForm(true); }}
          className="bg-slate-900 hover:bg-slate-800 rounded-xl h-11 px-5 font-semibold"
        >
          <Plus className="w-4 h-4 mr-2" /> Add Clause
        </Button>
      </div>

      {/* Form */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, y: -16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            className="bg-white border border-slate-200 rounded-2xl p-6 mb-8"
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-slate-900">
                {editingClause ? "Edit Clause" : "Add New Clause"}
              </h2>
              <button onClick={resetForm} className="p-2 hover:bg-slate-100 rounded-lg">
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>
            <div className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-slate-700">Title *</Label>
                  <Input
                    placeholder="e.g., Standard Limitation of Liability"
                    value={form.title}
                    onChange={(e) => setForm(p => ({ ...p, title: e.target.value }))}
                    className="h-11 rounded-xl border-slate-200"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-slate-700">Category *</Label>
                  <Select value={form.category} onValueChange={(v) => setForm(p => ({ ...p, category: v }))}>
                    <SelectTrigger className="h-11 rounded-xl border-slate-200">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(categoryLabels).map(([k, v]) => (
                        <SelectItem key={k} value={k}>{v}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium text-slate-700">Clause Language *</Label>
                <Textarea
                  placeholder="Paste or type your approved clause language here..."
                  value={form.clause_text}
                  onChange={(e) => setForm(p => ({ ...p, clause_text: e.target.value }))}
                  className="min-h-[150px] rounded-xl border-slate-200 text-sm"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium text-slate-700">Notes (optional)</Label>
                <Input
                  placeholder="When to use this clause, context, etc."
                  value={form.notes}
                  onChange={(e) => setForm(p => ({ ...p, notes: e.target.value }))}
                  className="h-11 rounded-xl border-slate-200"
                />
              </div>
              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={resetForm} className="rounded-xl">Cancel</Button>
                <Button
                  onClick={handleSubmit}
                  disabled={!form.title.trim() || !form.category || !form.clause_text.trim()}
                  className="bg-slate-900 hover:bg-slate-800 rounded-xl font-semibold"
                >
                  {editingClause ? "Update Clause" : "Save Clause"}
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input
            placeholder="Search clauses..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 h-11 rounded-xl border-slate-200"
          />
        </div>
        <Select value={filterCat} onValueChange={setFilterCat}>
          <SelectTrigger className="w-48 h-11 rounded-xl border-slate-200">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {Object.entries(categoryLabels).map(([k, v]) => (
              <SelectItem key={k} value={k}>{v}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* List */}
      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map(i => <Skeleton key={i} className="h-28 rounded-xl" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20">
          <div className="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center mx-auto mb-5">
            <BookOpen className="w-7 h-7 text-slate-400" />
          </div>
          <h3 className="text-lg font-semibold text-slate-800 mb-2">
            {clauses.length === 0 ? "No saved clauses yet" : "No matching clauses"}
          </h3>
          <p className="text-slate-500 max-w-sm mx-auto">
            {clauses.length === 0 ? "Save your preferred contract language to quickly swap it in during negotiations." : "Try adjusting your search or filter."}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((clause, i) => (
            <motion.div
              key={clause.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.04 }}
              className="bg-white border border-slate-200 rounded-xl p-5 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between gap-3 mb-3">
                <div>
                  <h3 className="font-semibold text-slate-800">{clause.title}</h3>
                  <span className={`inline-block text-xs font-medium px-2.5 py-0.5 rounded-full border mt-1.5 ${categoryColors[clause.category] || categoryColors.other}`}>
                    {categoryLabels[clause.category] || clause.category}
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost" size="icon"
                    onClick={() => handleCopy(clause.clause_text, clause.id)}
                    className="text-slate-400 hover:text-slate-700"
                  >
                    {copiedId === clause.id ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => handleEdit(clause)} className="text-slate-400 hover:text-slate-700">
                    <Pencil className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => setDeleteTarget(clause)} className="text-slate-400 hover:text-red-600">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <p className="text-sm text-slate-600 leading-relaxed line-clamp-3">{clause.clause_text}</p>
              {clause.notes && (
                <p className="text-xs text-slate-400 mt-2 italic">{clause.notes}</p>
              )}
            </motion.div>
          ))}
        </div>
      )}

      <AlertDialog open={!!deleteTarget} onOpenChange={() => setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete clause?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete "{deleteTarget?.title}" from your library.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteMutation.mutate(deleteTarget.id)} className="bg-red-600 hover:bg-red-700">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}