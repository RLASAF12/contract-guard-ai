import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Plus, Users, UserPlus, X, Trash2, FolderOpen, FileText } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { motion, AnimatePresence } from "framer-motion";
import PipelineCard from "@/components/pipeline/PipelineCard";

export default function WorkspaceDetail() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const workspaceId = urlParams.get("id");

  const [workspace, setWorkspace] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showInvite, setShowInvite] = useState(false);
  const [inviteForm, setInviteForm] = useState({ email: "", name: "", role: "viewer" });

  useEffect(() => {
    const load = async () => {
      if (!workspaceId) { navigate(createPageUrl("Workspaces")); return; }
      const results = await base44.entities.Workspace.filter({ id: workspaceId });
      if (results.length > 0) setWorkspace(results[0]);
      else navigate(createPageUrl("Workspaces"));
      setLoading(false);
    };
    load();
  }, [workspaceId]);

  const { data: contracts = [] } = useQuery({
    queryKey: ["ws-contracts", workspaceId],
    queryFn: () => base44.entities.Contract.filter({ workspace_id: workspaceId }, "-created_date"),
    enabled: !!workspaceId,
    initialData: [],
  });

  const members = (() => {
    try { return JSON.parse(workspace?.members || "[]"); } catch { return []; }
  })();

  const handleInvite = async () => {
    if (!inviteForm.email.trim() || !inviteForm.name.trim()) return;
    const updated = [...members, { email: inviteForm.email, name: inviteForm.name, role: inviteForm.role }];
    await base44.entities.Workspace.update(workspace.id, { members: JSON.stringify(updated) });

    await base44.integrations.Core.SendEmail({
      to: inviteForm.email,
      subject: `You've been invited to workspace: ${workspace.name}`,
      body: `<div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #0f172a;">Workspace Invitation</h2>
        <p>Hello ${inviteForm.name},</p>
        <p>You've been invited to the <strong>${workspace.name}</strong> workspace with <strong>${inviteForm.role}</strong> access.</p>
        <p style="color: #64748b; font-size: 13px;">Log in to ContractGuard AI to view and collaborate on contracts in this workspace.</p>
      </div>`,
    });

    setWorkspace(prev => ({ ...prev, members: JSON.stringify(updated) }));
    setInviteForm({ email: "", name: "", role: "viewer" });
    setShowInvite(false);
  };

  const handleRemoveMember = async (index) => {
    const updated = members.filter((_, i) => i !== index);
    await base44.entities.Workspace.update(workspace.id, { members: JSON.stringify(updated) });
    setWorkspace(prev => ({ ...prev, members: JSON.stringify(updated) }));
  };

  const roleLabels = { viewer: "Viewer", commenter: "Commenter", editor: "Editor" };
  const roleColors = { viewer: "bg-slate-100 text-slate-600", commenter: "bg-blue-100 text-blue-600", editor: "bg-emerald-100 text-emerald-600" };

  if (loading) {
    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-16 space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-40 rounded-2xl" />
      </div>
    );
  }

  if (!workspace) return null;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-12 sm:py-16">
      <Link to={createPageUrl("Workspaces")} className="inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-700 mb-4">
        <ArrowLeft className="w-4 h-4" /> Back to Workspaces
      </Link>

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">{workspace.name}</h1>
          {workspace.description && <p className="text-sm text-slate-500 mt-1">{workspace.description}</p>}
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setShowInvite(true)} className="rounded-xl">
            <UserPlus className="w-4 h-4 mr-2" /> Invite Member
          </Button>
          <Link to={createPageUrl("GenerateContract") + "?workspace=" + workspace.id}>
            <Button className="bg-slate-900 hover:bg-slate-800 rounded-xl">
              <Plus className="w-4 h-4 mr-2" /> New Contract
            </Button>
          </Link>
        </div>
      </div>

      {/* Members */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="bg-white border border-slate-200 rounded-2xl p-6 mb-8">
        <div className="flex items-center gap-2 mb-4">
          <Users className="w-5 h-5 text-slate-400" />
          <h2 className="font-semibold text-slate-900">Team Members</h2>
          <span className="text-xs bg-slate-100 text-slate-500 px-2 py-0.5 rounded-full">{members.length + 1}</span>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-slate-900 flex items-center justify-center text-white text-xs font-bold">O</div>
              <div>
                <p className="text-sm font-medium text-slate-800">{workspace.owner_email}</p>
                <p className="text-xs text-slate-400">Owner</p>
              </div>
            </div>
            <span className="text-xs font-semibold bg-slate-900 text-white px-2.5 py-0.5 rounded-full">Owner</span>
          </div>

          {members.map((m, i) => (
            <div key={i} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-500 text-xs font-bold">{m.name.charAt(0).toUpperCase()}</div>
                <div>
                  <p className="text-sm font-medium text-slate-800">{m.name}</p>
                  <p className="text-xs text-slate-400">{m.email}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full ${roleColors[m.role] || roleColors.viewer}`}>{roleLabels[m.role]}</span>
                <Button variant="ghost" size="icon" onClick={() => handleRemoveMember(i)} className="text-slate-400 hover:text-red-500 h-7 w-7"><Trash2 className="w-3.5 h-3.5" /></Button>
              </div>
            </div>
          ))}
        </div>

        <AnimatePresence>
          {showInvite && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden mt-4">
              <div className="bg-slate-50 rounded-xl p-4 space-y-3">
                <div className="grid sm:grid-cols-3 gap-3">
                  <div className="space-y-1"><Label className="text-xs">Name</Label><Input value={inviteForm.name} onChange={(e) => setInviteForm(p => ({ ...p, name: e.target.value }))} placeholder="Full name" className="h-9 rounded-lg border-slate-200 text-sm" /></div>
                  <div className="space-y-1"><Label className="text-xs">Email</Label><Input type="email" value={inviteForm.email} onChange={(e) => setInviteForm(p => ({ ...p, email: e.target.value }))} placeholder="email@example.com" className="h-9 rounded-lg border-slate-200 text-sm" /></div>
                  <div className="space-y-1">
                    <Label className="text-xs">Permission</Label>
                    <Select value={inviteForm.role} onValueChange={(v) => setInviteForm(p => ({ ...p, role: v }))}>
                      <SelectTrigger className="h-9 rounded-lg border-slate-200 text-sm"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="viewer">Viewer — can view only</SelectItem>
                        <SelectItem value="commenter">Commenter — can view & comment</SelectItem>
                        <SelectItem value="editor">Editor — full access</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="flex gap-2 justify-end">
                  <Button variant="ghost" size="sm" onClick={() => setShowInvite(false)} className="text-xs">Cancel</Button>
                  <Button size="sm" onClick={handleInvite} disabled={!inviteForm.email.trim() || !inviteForm.name.trim()} className="bg-slate-900 hover:bg-slate-800 text-xs rounded-lg">Send Invite</Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Contracts */}
      <div className="mb-4 flex items-center gap-2">
        <FileText className="w-5 h-5 text-slate-400" />
        <h2 className="font-semibold text-slate-900">Contracts</h2>
        <span className="text-xs bg-slate-100 text-slate-500 px-2 py-0.5 rounded-full">{contracts.length}</span>
      </div>

      {contracts.length === 0 ? (
        <div className="text-center py-16 bg-white border border-slate-200 rounded-2xl">
          <FolderOpen className="w-8 h-8 text-slate-300 mx-auto mb-3" />
          <p className="text-sm text-slate-500">No contracts in this workspace yet.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {contracts.map((c) => (
            <PipelineCard key={c.id} contract={c} isDragging={false} />
          ))}
        </div>
      )}
    </div>
  );
}