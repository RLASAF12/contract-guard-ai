import React, { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Save, ArrowLeft, CheckCircle, FileText, ShieldOff, Download, Loader2, Share2 } from "lucide-react";
import ShareModal from "@/components/contract/ShareModal";
import RiskBadge from "@/components/contract/RiskBadge";
import FindingCard from "@/components/contract/FindingCard";
import MissingProtectionCard from "@/components/contract/MissingProtectionCard";
import Disclaimer from "@/components/contract/Disclaimer";
import { motion } from "framer-motion";

const perspectiveLabels = {
  party_a: "Party A (offering)",
  party_b: "Party B (receiving)",
  neutral: "Neutral",
};

export default function Results() {
  const navigate = useNavigate();
  const [analysis, setAnalysis] = useState(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [showShare, setShowShare] = useState(false);

  useEffect(() => {
    const stored = sessionStorage.getItem("contractAnalysis");
    if (stored) {
      setAnalysis(JSON.parse(stored));
    } else {
      navigate(createPageUrl("Analyze"));
    }
  }, [navigate]);

  const handleSave = async () => {
    setSaving(true);
    const created = await base44.entities.Analysis.create(analysis);
    setAnalysis({ ...analysis, id: created.id });
    setSaved(true);
    setSaving(false);
    sessionStorage.removeItem("contractAnalysis");
  };

  const handleExportPdf = async () => {
    setExporting(true);
    const response = await base44.functions.invoke("exportPdf", { analysis }, { responseType: "arraybuffer" });
    const blob = new Blob([response.data], { type: "application/pdf" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${(analysis.contract_title || "analysis").replace(/[^a-zA-Z0-9]/g, "_")}_report.pdf`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setExporting(false);
  };

  if (!analysis) return null;

  const findings = (() => {
    try { return JSON.parse(analysis.key_findings) || []; } catch { return []; }
  })();
  const protections = (() => {
    try { return JSON.parse(analysis.missing_protections) || []; } catch { return []; }
  })();

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12 sm:py-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-10">
        <div>
          <Link
            to={createPageUrl("Analyze")}
            className="inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-700 mb-3"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Analyze
          </Link>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">{analysis.contract_title}</h1>
          <p className="text-sm text-slate-500 mt-1">Perspective: {perspectiveLabels[analysis.perspective]}</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {saved && analysis.id && (
            <Button
              variant="outline"
              onClick={() => setShowShare(true)}
              className="rounded-xl h-11 px-5 font-semibold"
            >
              <Share2 className="w-4 h-4 mr-2" />
              Share
            </Button>
          )}
          <Button
            variant="outline"
            onClick={handleExportPdf}
            disabled={exporting}
            className="rounded-xl h-11 px-5 font-semibold"
          >
            {exporting ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Download className="w-4 h-4 mr-2" />
            )}
            {exporting ? "Exporting..." : "Export PDF"}
          </Button>
          <Button
            onClick={handleSave}
            disabled={saving || saved}
            className={`rounded-xl h-11 px-6 font-semibold ${
              saved
                ? "bg-emerald-600 hover:bg-emerald-600"
                : "bg-slate-900 hover:bg-slate-800"
            }`}
          >
            {saved ? (
              <>
                <CheckCircle className="w-4 h-4 mr-2" />
                Saved
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                {saving ? "Saving..." : "Save Analysis"}
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Risk Score */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white border border-slate-200 rounded-2xl p-8 mb-6"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Overall Risk Score</p>
            <RiskBadge level={analysis.risk_score} size="lg" />
          </div>
        </div>
      </motion.div>

      {/* Executive Summary */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white border border-slate-200 rounded-2xl p-8 mb-6"
      >
        <h2 className="text-lg font-semibold text-slate-900 mb-3">Executive Summary</h2>
        <p className="text-slate-600 leading-relaxed">{analysis.executive_summary}</p>
      </motion.div>

      {/* Key Findings */}
      {findings.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-6"
        >
          <div className="flex items-center gap-2.5 mb-4">
            <FileText className="w-5 h-5 text-slate-400" />
            <h2 className="text-lg font-semibold text-slate-900">Key Findings</h2>
            <span className="bg-slate-100 text-slate-500 text-xs font-semibold px-2.5 py-0.5 rounded-full">
              {findings.length}
            </span>
          </div>
          <div className="space-y-3">
            {findings.map((finding, i) => (
              <FindingCard key={i} finding={finding} index={i} perspective={analysis.perspective} />
            ))}
          </div>
        </motion.div>
      )}

      {/* Missing Protections */}
      {protections.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-6"
        >
          <div className="flex items-center gap-2.5 mb-4">
            <ShieldOff className="w-5 h-5 text-orange-500" />
            <h2 className="text-lg font-semibold text-slate-900">Missing Protections</h2>
            <span className="bg-orange-100 text-orange-600 text-xs font-semibold px-2.5 py-0.5 rounded-full">
              {protections.length}
            </span>
          </div>
          <div className="space-y-3">
            {protections.map((p, i) => (
              <MissingProtectionCard key={i} protection={p} index={i} />
            ))}
          </div>
        </motion.div>
      )}

      <div className="mt-8">
        <Disclaimer />
      </div>

      {showShare && analysis.id && (
        <ShareModal
          analysis={analysis}
          onClose={() => setShowShare(false)}
          onTokenGenerated={(token) => setAnalysis({ ...analysis, share_token: token })}
        />
      )}
    </div>
  );
}