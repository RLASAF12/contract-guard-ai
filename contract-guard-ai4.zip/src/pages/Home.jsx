import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowRight, Shield, Search, FileCheck, AlertTriangle, ArrowLeftRight, Upload, FileText, BookOpen, Columns3, PenLine, FolderOpen, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import Disclaimer from "@/components/contract/Disclaimer";

const features = [
  {
    icon: Search,
    title: "Deep Clause Analysis",
    description: "Every clause is examined for hidden risks, ambiguous language, and one-sided terms.",
  },
  {
    icon: AlertTriangle,
    title: "Risk Identification",
    description: "Get a clear risk score and understand exactly which parts of the contract need attention.",
  },
  {
    icon: FileCheck,
    title: "Improvement Suggestions",
    description: "Receive actionable suggestions to negotiate better terms and protect your interests.",
  },
  {
    icon: ArrowLeftRight,
    title: "Version Comparison",
    description: "Compare two contract versions side-by-side and see how changes affect your risk level.",
  },
  {
    icon: Upload,
    title: "File Upload Support",
    description: "Upload PDF or Word documents directly — text is extracted automatically for analysis.",
  },
  {
    icon: FileText,
    title: "Contract Generator",
    description: "Generate full, professionally formatted contracts from scratch based on your requirements.",
  },
  {
    icon: BookOpen,
    title: "Clause Library",
    description: "Save pre-approved language and swap it into risky clauses during the negotiation process.",
  },
  {
    icon: Columns3,
    title: "Contract Pipeline",
    description: "Track contracts through Drafting, Negotiation, Signature, and Execution on a visual board.",
  },
  {
    icon: PenLine,
    title: "E-Signature Workflow",
    description: "Add signers, send contracts for legally binding e-signature, and track status in real-time.",
  },
  {
    icon: FolderOpen,
    title: "Workspaces",
    description: "Group contracts by project or client and invite team members with custom permissions.",
  },
  {
    icon: Eye,
    title: "Visual Diff",
    description: "Upload two versions and see color-coded additions, deletions, and modifications with risk impact.",
  },
];

export default function Home() {
  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900" />
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: "radial-gradient(circle at 1px 1px, rgba(255,255,255,0.15) 1px, transparent 0)",
          backgroundSize: "40px 40px"
        }} />
        
        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 py-24 sm:py-32 lg:py-40">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto"
          >
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/10 rounded-full px-4 py-1.5 mb-8">
              <Shield className="w-4 h-4 text-emerald-400" />
              <span className="text-sm text-slate-300 font-medium">AI-Powered Contract Analysis</span>
            </div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white tracking-tight leading-[1.1]">
              Understand Any Contract{" "}
              <span className="bg-gradient-to-r from-emerald-400 to-sky-400 bg-clip-text text-transparent">
                in Seconds
              </span>
            </h1>
            
            <p className="mt-6 text-lg sm:text-xl text-slate-400 max-w-2xl mx-auto leading-relaxed">
              Paste your contract text and get an instant AI analysis of risks, problematic clauses, and missing protections — tailored to your perspective.
            </p>
            
            <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to={createPageUrl("Analyze")}>
                <Button size="lg" className="bg-white text-slate-900 hover:bg-slate-100 h-13 px-8 text-base font-semibold rounded-xl shadow-lg shadow-black/20">
                  Analyze a Contract
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <Link to={createPageUrl("GenerateContract")}>
                <Button variant="ghost" size="lg" className="text-slate-400 hover:text-white hover:bg-white/10 h-13 px-8 text-base rounded-xl">
                  Generate a Contract
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-20 sm:py-28">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight">How It Works</h2>
          <p className="mt-4 text-slate-500 text-lg max-w-xl mx-auto">
            Three steps to a safer contract signing experience.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
              className="bg-white border border-slate-200 rounded-2xl p-8 hover:shadow-xl hover:border-slate-300 transition-all duration-300"
            >
              <div className="w-12 h-12 rounded-xl bg-slate-900 flex items-center justify-center mb-5">
                <feature.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-slate-900 mb-2">{feature.title}</h3>
              <p className="text-slate-500 text-sm leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Steps */}
      <section className="bg-white border-y border-slate-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-20 sm:py-28">
          <div className="grid sm:grid-cols-3 gap-12">
            {[
              { step: "01", title: "Upload or Paste Your Contract", desc: "Upload a PDF/Word file or paste the full text of any contract you need reviewed." },
              { step: "02", title: "Choose Your Perspective", desc: "Tell us which party you represent for a tailored risk analysis." },
              { step: "03", title: "Get Your Analysis", desc: "Receive a detailed breakdown of risks, issues, and suggestions." },
            ].map((item, i) => (
              <motion.div
                key={item.step}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                className="text-center"
              >
                <div className="text-5xl font-bold text-slate-200 mb-4">{item.step}</div>
                <h3 className="text-lg font-semibold text-slate-900 mb-2">{item.title}</h3>
                <p className="text-sm text-slate-500 leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-20 sm:py-28">
        <div className="bg-slate-900 rounded-3xl p-10 sm:p-16 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">Ready to analyze your contract?</h2>
          <p className="mt-4 text-slate-400 text-lg max-w-lg mx-auto">Know what you're signing before you sign it.</p>
          <Link to={createPageUrl("Analyze")}>
            <Button size="lg" className="mt-8 bg-white text-slate-900 hover:bg-slate-100 h-13 px-8 text-base font-semibold rounded-xl">
              Get Started Free
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </div>
        <div className="mt-8">
          <Disclaimer />
        </div>
      </section>
    </div>
  );
}