import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Shield, FileText, ShieldOff } from "lucide-react";
import RiskBadge from "@/components/contract/RiskBadge";
import MissingProtectionCard from "@/components/contract/MissingProtectionCard";
import Disclaimer from "@/components/contract/Disclaimer";
import SharedFindingCard from "@/components/contract/SharedFindingCard";
import { motion } from "framer-motion";
import { Skeleton } from "@/components/ui/skeleton";

const perspectiveLabels = {
  party_a: "Party A (offering)",
  party_b: "Party B (receiving)",
  neutral: "Neutral",
};

export default function SharedReport() {
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const urlParams = new URLSearchParams(window.location.search);
  const token = urlParams.get("token");

  useEffect(() => {
    const load = async () => {
      if (!token) { setError(true); setLoading(false); return; }
      const results = await base44.entities.Analysis.filter({ share_token: token });
      if (results.length > 0) {
        setAnalysis(results[0]);
      } else {
        setError(true);
      }
      setLoading(false);
    };
    load();
  }, [token]);

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-16 space-y-6">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-32 rounded-2xl" />
        <Skeleton className="h-32 rounded-2xl" />
      </div>
    );
  }

  if (error || !analysis) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-24 text-center">
        <div className="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center mx-auto mb-5">
          <Shield className="w-7 h-7 text-slate-400" />
        </div>
        <h2 className="text-xl font-bold text-slate-900 mb-2">Report Not Found</h2>
        <p className="text-slate-500">This share link is invalid or has expired.</p>
      </div>
    );
  }

  const findings = (() => {
    try { return JSON.parse(analysis.key_findings) || []; } catch { return []; }
  })();
  const protections = (() => {
    try { return JSON.parse(analysis.missing_protections) || []; } catch { return []; }
  })();

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12 sm:py-16">
      {/* Shared banner */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-8 flex items-center gap-3">
        <Shield className="w-5 h-5 text-blue-500 flex-shrink-0" />
        <p className="text-sm text-blue-700">
          You're viewing a shared report. You can add comments on any finding below.
        </p>
      </div>

      <div className="mb-10">
        <h1 className="text-3xl font-bold text-slate-900 tracking-tight">{analysis.contract_title}</h1>
        <p className="text-sm text-slate-500 mt-1">Perspective: {perspectiveLabels[analysis.perspective]}</p>
      </div>

      {/* Risk Score */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white border border-slate-200 rounded-2xl p-8 mb-6"
      >
        <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Overall Risk Score</p>
        <RiskBadge level={analysis.risk_score} size="lg" />
      </motion.div>

      {/* Executive Summary */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white border border-slate-200 rounded-2xl p-8 mb-6"
      >
        <h2 className="text-lg font-semibold text-slate-900 mb-3">Executive Summary</h2>
        <p className="text-slate-600 leading-relaxed">{analysis.executive_summary}</p>
      </motion.div>

      {/* Key Findings with comments */}
      {findings.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-6"
        >
          <div className="flex items-center gap-2.5 mb-4">
            <FileText className="w-5 h-5 text-slate-400" />
            <h2 className="text-lg font-semibold text-slate-900">Key Findings</h2>
            <span className="bg-slate-100 text-slate-500 text-xs font-semibold px-2.5 py-0.5 rounded-full">
              {findings.length}
            </span>
          </div>
          <div className="space-y-3">
            {findings.map((finding, i) => (
              <SharedFindingCard
                key={i}
                finding={finding}
                index={i}
                analysisId={analysis.id}
                shareToken={token}
              />
            ))}
          </div>
        </motion.div>
      )}

      {/* Missing Protections */}
      {protections.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-6"
        >
          <div className="flex items-center gap-2.5 mb-4">
            <ShieldOff className="w-5 h-5 text-orange-500" />
            <h2 className="text-lg font-semibold text-slate-900">Missing Protections</h2>
            <span className="bg-orange-100 text-orange-600 text-xs font-semibold px-2.5 py-0.5 rounded-full">
              {protections.length}
            </span>
          </div>
          <div className="space-y-3">
            {protections.map((p, i) => (
              <MissingProtectionCard key={i} protection={p} index={i} />
            ))}
          </div>
        </motion.div>
      )}

      <div className="mt-8">
        <Disclaimer />
      </div>
    </div>
  );
}