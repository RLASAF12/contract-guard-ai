import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowRight, Loader2, FileText } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import LoadingAnalysis from "@/components/contract/LoadingAnalysis";
import Disclaimer from "@/components/contract/Disclaimer";

const contractTypes = [
  { value: "service_agreement", label: "Service Agreement" },
  { value: "nda", label: "Non-Disclosure Agreement (NDA)" },
  { value: "employment", label: "Employment Contract" },
  { value: "freelance", label: "Freelance / Independent Contractor" },
  { value: "lease", label: "Lease Agreement" },
  { value: "partnership", label: "Partnership Agreement" },
  { value: "licensing", label: "Licensing Agreement" },
  { value: "sales", label: "Sales Contract" },
  { value: "other", label: "Other" },
];

export default function GenerateContract() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const presetWorkspace = urlParams.get("workspace") || "";

  const { data: workspaces = [] } = useQuery({
    queryKey: ["workspaces-gen"],
    queryFn: () => base44.entities.Workspace.list("-created_date"),
    initialData: [],
  });

  const [form, setForm] = useState({
    contract_type: "",
    party_a_name: "",
    party_b_name: "",
    jurisdiction: "",
    contract_value: "",
    start_date: "",
    end_date: "",
    additional_terms: "",
    workspace_id: presetWorkspace,
  });
  const [loading, setLoading] = useState(false);

  const update = (field, value) => setForm(prev => ({ ...prev, [field]: value }));

  const typeLabel = contractTypes.find(t => t.value === form.contract_type)?.label || form.contract_type;

  const handleGenerate = async () => {
    setLoading(true);

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an expert legal document drafter. Generate a complete, professionally formatted contract based on the following specifications:

Contract Type: ${typeLabel}
Party A: ${form.party_a_name}
Party B: ${form.party_b_name}
Jurisdiction: ${form.jurisdiction || "United States"}
${form.contract_value ? `Contract Value: $${form.contract_value}` : ""}
${form.start_date ? `Start Date: ${form.start_date}` : ""}
${form.end_date ? `End Date: ${form.end_date}` : ""}
${form.additional_terms ? `Additional Requirements: ${form.additional_terms}` : ""}

Generate a complete, legally sound contract that includes:
- A proper title and preamble identifying the parties
- Recitals/Background section
- All standard sections appropriate for this contract type (scope, payment, term, termination, confidentiality, liability, indemnification, dispute resolution, etc.)
- Governing law and jurisdiction clause
- Signature blocks for both parties
- Clear section numbering

The contract should be balanced, professional, and ready for legal review. Use standard legal language but keep it readable.
Return the full contract text as a single string with proper formatting using newlines.`,
      response_json_schema: {
        type: "object",
        properties: {
          title: { type: "string" },
          contract_text: { type: "string" },
        },
      },
    });

    const title = result.title || `${typeLabel} - ${form.party_a_name} & ${form.party_b_name}`;

    const contractData = {
      title,
      contract_type: form.contract_type,
      party_a_name: form.party_a_name,
      party_b_name: form.party_b_name,
      jurisdiction: form.jurisdiction || "United States",
      contract_value: form.contract_value ? parseFloat(form.contract_value) : undefined,
      start_date: form.start_date || undefined,
      end_date: form.end_date || undefined,
      stage: "drafting",
      contract_text: result.contract_text,
    };
    if (form.workspace_id) contractData.workspace_id = form.workspace_id;
    const contract = await base44.entities.Contract.create(contractData);

    navigate(createPageUrl("ContractPreview") + "?id=" + contract.id);
    setLoading(false);
  };

  const canSubmit = form.contract_type && form.party_a_name.trim() && form.party_b_name.trim();

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-16">
        <LoadingAnalysis />
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12 sm:py-16">
      <div className="mb-10">
        <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Generate Contract</h1>
        <p className="mt-2 text-slate-500">
          Provide key details and AI will draft a professionally formatted contract for you.
        </p>
      </div>

      <div className="space-y-6">
        <div className="space-y-2">
          <Label className="text-sm font-medium text-slate-700">Contract Type *</Label>
          <Select value={form.contract_type} onValueChange={(v) => update("contract_type", v)}>
            <SelectTrigger className="h-12 rounded-xl border-slate-200">
              <SelectValue placeholder="Select a contract type" />
            </SelectTrigger>
            <SelectContent>
              {contractTypes.map(t => (
                <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="text-sm font-medium text-slate-700">Party A Name *</Label>
            <Input
              placeholder="e.g., Acme Corporation"
              value={form.party_a_name}
              onChange={(e) => update("party_a_name", e.target.value)}
              className="h-12 rounded-xl border-slate-200"
            />
          </div>
          <div className="space-y-2">
            <Label className="text-sm font-medium text-slate-700">Party B Name *</Label>
            <Input
              placeholder="e.g., Jane Smith"
              value={form.party_b_name}
              onChange={(e) => update("party_b_name", e.target.value)}
              className="h-12 rounded-xl border-slate-200"
            />
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="text-sm font-medium text-slate-700">Jurisdiction</Label>
            <Input
              placeholder="e.g., State of California, USA"
              value={form.jurisdiction}
              onChange={(e) => update("jurisdiction", e.target.value)}
              className="h-12 rounded-xl border-slate-200"
            />
          </div>
          <div className="space-y-2">
            <Label className="text-sm font-medium text-slate-700">Contract Value (USD)</Label>
            <Input
              type="number"
              placeholder="e.g., 50000"
              value={form.contract_value}
              onChange={(e) => update("contract_value", e.target.value)}
              className="h-12 rounded-xl border-slate-200"
            />
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="text-sm font-medium text-slate-700">Start Date</Label>
            <Input
              type="date"
              value={form.start_date}
              onChange={(e) => update("start_date", e.target.value)}
              className="h-12 rounded-xl border-slate-200"
            />
          </div>
          <div className="space-y-2">
            <Label className="text-sm font-medium text-slate-700">End Date</Label>
            <Input
              type="date"
              value={form.end_date}
              onChange={(e) => update("end_date", e.target.value)}
              className="h-12 rounded-xl border-slate-200"
            />
          </div>
        </div>

        {workspaces.length > 0 && (
          <div className="space-y-2">
            <Label className="text-sm font-medium text-slate-700">Workspace (optional)</Label>
            <Select value={form.workspace_id} onValueChange={(v) => update("workspace_id", v)}>
              <SelectTrigger className="h-12 rounded-xl border-slate-200">
                <SelectValue placeholder="No workspace" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value=" ">No Workspace</SelectItem>
                {workspaces.map(ws => (
                  <SelectItem key={ws.id} value={ws.id}>{ws.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        <div className="space-y-2">
          <Label className="text-sm font-medium text-slate-700">Additional Terms or Requirements</Label>
          <Textarea
            placeholder="e.g., Include non-compete clause, specify payment terms of Net 30, add IP ownership provisions..."
            value={form.additional_terms}
            onChange={(e) => update("additional_terms", e.target.value)}
            className="min-h-[120px] rounded-xl border-slate-200 text-sm"
          />
        </div>

        <Button
          onClick={handleGenerate}
          disabled={!canSubmit}
          className="w-full h-13 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-base font-semibold disabled:opacity-40"
        >
          <FileText className="w-5 h-5 mr-2" />
          Generate Contract
        </Button>

        <Disclaimer />
      </div>
    </div>
  );
}