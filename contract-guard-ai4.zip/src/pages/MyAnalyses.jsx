import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { FileText, Plus } from "lucide-react";
import ShareModal from "@/components/contract/ShareModal";
import { AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import AnalysisCard from "@/components/contract/AnalysisCard";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function MyAnalyses() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [shareTarget, setShareTarget] = useState(null);

  const { data: analyses, isLoading } = useQuery({
    queryKey: ["analyses"],
    queryFn: () => base44.entities.Analysis.list("-created_date"),
    initialData: [],
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Analysis.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["analyses"] });
      setDeleteTarget(null);
    },
  });

  const handleView = (analysis) => {
    sessionStorage.setItem("contractAnalysis", JSON.stringify(analysis));
    navigate(createPageUrl("Results"));
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12 sm:py-16">
      <div className="flex items-center justify-between mb-10">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">My Analyses</h1>
          <p className="mt-1 text-slate-500">Your saved contract analyses.</p>
        </div>
        <Link to={createPageUrl("Analyze")}>
          <Button className="bg-slate-900 hover:bg-slate-800 rounded-xl h-11 px-5 font-semibold">
            <Plus className="w-4 h-4 mr-2" />
            New Analysis
          </Button>
        </Link>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-white border border-slate-200 rounded-xl p-5">
              <div className="flex items-start gap-4">
                <Skeleton className="w-11 h-11 rounded-xl" />
                <div className="flex-1">
                  <Skeleton className="h-5 w-48 mb-2" />
                  <Skeleton className="h-4 w-32" />
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : analyses.length === 0 ? (
        <div className="text-center py-24">
          <div className="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center mx-auto mb-5">
            <FileText className="w-7 h-7 text-slate-400" />
          </div>
          <h3 className="text-lg font-semibold text-slate-800 mb-2">No analyses yet</h3>
          <p className="text-slate-500 mb-6">Analyze your first contract to see it here.</p>
          <Link to={createPageUrl("Analyze")}>
            <Button className="bg-slate-900 hover:bg-slate-800 rounded-xl h-11 px-6 font-semibold">
              Analyze a Contract
            </Button>
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          {analyses.map((a, i) => (
            <AnalysisCard
              key={a.id}
              analysis={a}
              index={i}
              onView={handleView}
              onDelete={setDeleteTarget}
              onShare={setShareTarget}
            />
          ))}
        </div>
      )}

      <AnimatePresence>
        {shareTarget && (
          <ShareModal
            analysis={shareTarget}
            onClose={() => setShareTarget(null)}
            onTokenGenerated={(token) => {
              setShareTarget(prev => ({ ...prev, share_token: token }));
              queryClient.invalidateQueries({ queryKey: ["analyses"] });
            }}
          />
        )}
      </AnimatePresence>

      <AlertDialog open={!!deleteTarget} onOpenChange={() => setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete analysis?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the analysis for "{deleteTarget?.contract_title}". This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteMutation.mutate(deleteTarget.id)}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}