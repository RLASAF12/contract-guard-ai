import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowRight } from "lucide-react";
import LoadingAnalysis from "@/components/contract/LoadingAnalysis";
import Disclaimer from "@/components/contract/Disclaimer";
import FileUploader from "@/components/contract/FileUploader";

export default function Analyze() {
  const navigate = useNavigate();
  const [title, setTitle] = useState(() => {
    const prefill = sessionStorage.getItem("prefillContractTitle");
    if (prefill) { sessionStorage.removeItem("prefillContractTitle"); return prefill; }
    return "";
  });
  const [contractText, setContractText] = useState(() => {
    const prefill = sessionStorage.getItem("prefillContractText");
    if (prefill) { sessionStorage.removeItem("prefillContractText"); return prefill; }
    return "";
  });
  const [perspective, setPerspective] = useState("");
  const [loading, setLoading] = useState(false);
  const [inputMode, setInputMode] = useState("paste");

  const handleAnalyze = async () => {
    if (!contractText.trim() || !perspective) return;

    setLoading(true);

    const perspectiveLabel =
      perspective === "party_a"
        ? "Party A (the one offering/drafting the contract)"
        : perspective === "party_b"
        ? "Party B (the one receiving/signing the contract)"
        : "a neutral third-party observer";

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an expert contract risk analyst. Analyze the following contract from the perspective of ${perspectiveLabel}.

Your analysis must include:
1. An overall risk score: "low", "medium", or "high"
2. An executive summary (2-3 concise sentences)
3. Key findings — a list of flagged clauses. For each, provide:
   - A short title for the issue
   - The exact or near-exact clause text from the contract
   - The risk level: "low", "medium", or "high"
   - An explanation of why it's risky from the given perspective
   - A suggested improvement or alternative language
4. Missing protections — things the contract should include but doesn't. For each, provide:
   - A title
   - A description of why it's important

Contract text:
"""
${contractText}
"""`,
      response_json_schema: {
        type: "object",
        properties: {
          risk_score: { type: "string", enum: ["low", "medium", "high"] },
          executive_summary: { type: "string" },
          key_findings: {
            type: "array",
            items: {
              type: "object",
              properties: {
                title: { type: "string" },
                clause_text: { type: "string" },
                risk_level: { type: "string", enum: ["low", "medium", "high"] },
                explanation: { type: "string" },
                suggestion: { type: "string" },
              },
            },
          },
          missing_protections: {
            type: "array",
            items: {
              type: "object",
              properties: {
                title: { type: "string" },
                description: { type: "string" },
              },
            },
          },
        },
      },
    });

    const analysisData = {
      contract_title: title.trim() || "Untitled Contract",
      contract_text: contractText,
      perspective,
      risk_score: result.risk_score,
      executive_summary: result.executive_summary,
      key_findings: JSON.stringify(result.key_findings || []),
      missing_protections: JSON.stringify(result.missing_protections || []),
    };

    // Store in sessionStorage for the results page
    sessionStorage.setItem("contractAnalysis", JSON.stringify(analysisData));

    setLoading(false);
    navigate(createPageUrl("Results"));
  };

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-16">
        <LoadingAnalysis />
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12 sm:py-16">
      <div className="mb-10">
        <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Analyze a Contract</h1>
        <p className="mt-2 text-slate-500">
          Paste or upload your contract and select your perspective for a tailored risk analysis.
        </p>
      </div>

      <div className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="title" className="text-sm font-medium text-slate-700">Contract Title (optional)</Label>
          <Input
            id="title"
            placeholder="e.g., Freelance Design Agreement"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="h-12 rounded-xl border-slate-200 focus:border-slate-400 focus:ring-slate-400"
          />
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label className="text-sm font-medium text-slate-700">Contract Text</Label>
            <Tabs value={inputMode} onValueChange={setInputMode}>
              <TabsList className="bg-slate-100 h-8">
                <TabsTrigger value="paste" className="text-xs px-3 h-6">Paste Text</TabsTrigger>
                <TabsTrigger value="upload" className="text-xs px-3 h-6">Upload File</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          {inputMode === "upload" && (
            <FileUploader onTextExtracted={(text) => setContractText(text)} />
          )}
          <Textarea
            id="contract"
            placeholder="Paste the full contract text here..."
            value={contractText}
            onChange={(e) => setContractText(e.target.value)}
            className="min-h-[300px] rounded-xl border-slate-200 focus:border-slate-400 focus:ring-slate-400 resize-y text-sm leading-relaxed"
          />
          <p className="text-xs text-slate-400">{contractText.length.toLocaleString()} characters</p>
        </div>

        <div className="space-y-2">
          <Label className="text-sm font-medium text-slate-700">Your Perspective</Label>
          <Select value={perspective} onValueChange={setPerspective}>
            <SelectTrigger className="h-12 rounded-xl border-slate-200">
              <SelectValue placeholder="Select your role in this contract" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="party_a">I am Party A (offering the contract)</SelectItem>
              <SelectItem value="party_b">I am Party B (receiving the contract)</SelectItem>
              <SelectItem value="neutral">Neutral analysis</SelectItem>
            </SelectContent>
          </Select>
          <p className="text-xs text-slate-400">
            Risks differ based on which side you're on — selecting your role ensures relevant insights.
          </p>
        </div>

        <Button
          onClick={handleAnalyze}
          disabled={!contractText.trim() || !perspective}
          className="w-full h-13 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-base font-semibold disabled:opacity-40"
        >
          Analyze Contract
          <ArrowRight className="w-5 h-5 ml-2" />
        </Button>

        <Disclaimer />
      </div>
    </div>
  );
}