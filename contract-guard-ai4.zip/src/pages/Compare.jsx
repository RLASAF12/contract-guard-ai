import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowRight, ArrowLeftRight, FileText, ShieldOff } from "lucide-react";
import LoadingAnalysis from "@/components/contract/LoadingAnalysis";
import Disclaimer from "@/components/contract/Disclaimer";
import FileUploader from "@/components/contract/FileUploader";
import ComparisonDiff from "@/components/contract/ComparisonDiff";
import RiskBadge from "@/components/contract/RiskBadge";
import MissingProtectionCard from "@/components/contract/MissingProtectionCard";
import { motion } from "framer-motion";

export default function Compare() {
  const [originalText, setOriginalText] = useState("");
  const [revisedText, setRevisedText] = useState("");
  const [perspective, setPerspective] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [inputMode, setInputMode] = useState("paste");

  const handleCompare = async () => {
    if (!originalText.trim() || !revisedText.trim() || !perspective) return;
    setLoading(true);
    setResult(null);

    const perspectiveLabel =
      perspective === "party_a"
        ? "Party A (the one offering/drafting the contract)"
        : perspective === "party_b"
        ? "Party B (the one receiving/signing the contract)"
        : "a neutral third-party observer";

    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an expert contract risk analyst. Compare the following two versions of a contract from the perspective of ${perspectiveLabel}.

Identify all meaningful differences between the ORIGINAL and REVISED versions. For each change:
- Classify it as "added" (new clause in revised), "removed" (clause removed in revised), or "modified" (changed wording)
- Provide the original and/or new clause text
- Rate the risk impact of this specific change: "low", "medium", or "high"
- Explain the impact of this change on the user's position

Also provide:
- An overall risk comparison: did the revised version increase, decrease, or maintain the overall risk level?
- An overall risk score for the revised version: "low", "medium", or "high"
- A summary of the comparison (2-3 sentences)
- Any new missing protections introduced by the changes

ORIGINAL VERSION:
"""
${originalText}
"""

REVISED VERSION:
"""
${revisedText}
"""`,
      response_json_schema: {
        type: "object",
        properties: {
          overall_risk_score: { type: "string", enum: ["low", "medium", "high"] },
          risk_direction: { type: "string", enum: ["increased", "decreased", "unchanged"] },
          comparison_summary: { type: "string" },
          changes: {
            type: "array",
            items: {
              type: "object",
              properties: {
                change_type: { type: "string", enum: ["added", "removed", "modified"] },
                title: { type: "string" },
                old_text: { type: "string" },
                new_text: { type: "string" },
                clause_text: { type: "string" },
                risk_impact: { type: "string", enum: ["low", "medium", "high"] },
                explanation: { type: "string" },
              },
            },
          },
          new_missing_protections: {
            type: "array",
            items: {
              type: "object",
              properties: {
                title: { type: "string" },
                description: { type: "string" },
              },
            },
          },
        },
      },
    });

    setResult(res);
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-16">
        <LoadingAnalysis />
      </div>
    );
  }

  const directionLabels = {
    increased: { text: "Risk Increased", color: "text-red-600", bg: "bg-red-50", border: "border-red-200" },
    decreased: { text: "Risk Decreased", color: "text-emerald-600", bg: "bg-emerald-50", border: "border-emerald-200" },
    unchanged: { text: "Risk Unchanged", color: "text-amber-600", bg: "bg-amber-50", border: "border-amber-200" },
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-12 sm:py-16">
      <div className="mb-10">
        <div className="flex items-center gap-3 mb-2">
          <ArrowLeftRight className="w-7 h-7 text-slate-400" />
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Compare Versions</h1>
        </div>
        <p className="text-slate-500">
          Paste or upload two versions of the same contract. The AI will highlight differences and assess risk changes.
        </p>
      </div>

      {!result ? (
        <div className="space-y-6">
          <div className="flex items-center gap-4">
            <Label className="text-sm font-medium text-slate-700">Input method:</Label>
            <Tabs value={inputMode} onValueChange={setInputMode}>
              <TabsList className="bg-slate-100">
                <TabsTrigger value="paste">Paste Text</TabsTrigger>
                <TabsTrigger value="upload">Upload Files</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <Label className="text-sm font-semibold text-slate-700">Original Version</Label>
              {inputMode === "upload" && (
                <FileUploader
                  onTextExtracted={(text) => setOriginalText(text)}
                />
              )}
              <Textarea
                placeholder="Paste the original contract text..."
                value={originalText}
                onChange={(e) => setOriginalText(e.target.value)}
                className="min-h-[250px] rounded-xl border-slate-200 text-sm resize-y"
              />
              <p className="text-xs text-slate-400">{originalText.length.toLocaleString()} characters</p>
            </div>
            <div className="space-y-3">
              <Label className="text-sm font-semibold text-slate-700">Revised Version</Label>
              {inputMode === "upload" && (
                <FileUploader
                  onTextExtracted={(text) => setRevisedText(text)}
                />
              )}
              <Textarea
                placeholder="Paste the revised contract text..."
                value={revisedText}
                onChange={(e) => setRevisedText(e.target.value)}
                className="min-h-[250px] rounded-xl border-slate-200 text-sm resize-y"
              />
              <p className="text-xs text-slate-400">{revisedText.length.toLocaleString()} characters</p>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-medium text-slate-700">Your Perspective</Label>
            <Select value={perspective} onValueChange={setPerspective}>
              <SelectTrigger className="h-12 rounded-xl border-slate-200">
                <SelectValue placeholder="Select your role in this contract" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="party_a">I am Party A (offering the contract)</SelectItem>
                <SelectItem value="party_b">I am Party B (receiving the contract)</SelectItem>
                <SelectItem value="neutral">Neutral analysis</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button
            onClick={handleCompare}
            disabled={!originalText.trim() || !revisedText.trim() || !perspective}
            className="w-full h-13 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-base font-semibold disabled:opacity-40"
          >
            Compare Versions
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
          <Disclaimer />
        </div>
      ) : (
        <div className="space-y-6">
          <Button variant="outline" onClick={() => setResult(null)} className="rounded-xl">
            ← New Comparison
          </Button>

          {/* Risk overview */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white border border-slate-200 rounded-2xl p-8"
          >
            <div className="flex flex-wrap items-center gap-4 mb-4">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Revised Version Risk</p>
                <RiskBadge level={result.overall_risk_score} size="lg" />
              </div>
              {result.risk_direction && (
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Change Direction</p>
                  <span className={`inline-flex items-center px-4 py-2 rounded-full border font-semibold text-sm ${directionLabels[result.risk_direction]?.bg} ${directionLabels[result.risk_direction]?.border} ${directionLabels[result.risk_direction]?.color}`}>
                    {directionLabels[result.risk_direction]?.text}
                  </span>
                </div>
              )}
            </div>
            <p className="text-slate-600 leading-relaxed">{result.comparison_summary}</p>
          </motion.div>

          {/* Changes */}
          {result.changes?.length > 0 && (
            <div>
              <div className="flex items-center gap-2.5 mb-4">
                <FileText className="w-5 h-5 text-slate-400" />
                <h2 className="text-lg font-semibold text-slate-900">Changes Detected</h2>
                <span className="bg-slate-100 text-slate-500 text-xs font-semibold px-2.5 py-0.5 rounded-full">
                  {result.changes.length}
                </span>
              </div>
              <div className="space-y-3">
                {result.changes.map((change, i) => (
                  <ComparisonDiff key={i} change={change} index={i} />
                ))}
              </div>
            </div>
          )}

          {/* New Missing Protections */}
          {result.new_missing_protections?.length > 0 && (
            <div>
              <div className="flex items-center gap-2.5 mb-4">
                <ShieldOff className="w-5 h-5 text-orange-500" />
                <h2 className="text-lg font-semibold text-slate-900">New Missing Protections</h2>
                <span className="bg-orange-100 text-orange-600 text-xs font-semibold px-2.5 py-0.5 rounded-full">
                  {result.new_missing_protections.length}
                </span>
              </div>
              <div className="space-y-3">
                {result.new_missing_protections.map((p, i) => (
                  <MissingProtectionCard key={i} protection={p} index={i} />
                ))}
              </div>
            </div>
          )}

          <Disclaimer />
        </div>
      )}
    </div>
  );
}