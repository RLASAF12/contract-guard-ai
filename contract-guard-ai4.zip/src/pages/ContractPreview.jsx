import React, { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Download, Copy, Check, Search, Loader2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import Disclaimer from "@/components/contract/Disclaimer";
import SignatureManager from "@/components/contract/SignatureManager";
import { motion } from "framer-motion";

const stageLabels = {
  drafting: "Drafting",
  in_negotiation: "In Negotiation",
  pending_signature: "Pending Signature",
  executed: "Executed",
};

export default function ContractPreview() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const contractId = urlParams.get("id");

  const [contract, setContract] = useState(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);

  useEffect(() => {
    const load = async () => {
      if (!contractId) { navigate(createPageUrl("Pipeline")); return; }
      const results = await base44.entities.Contract.filter({ id: contractId });
      if (results.length > 0) setContract(results[0]);
      else navigate(createPageUrl("Pipeline"));
      setLoading(false);
    };
    load();
  }, [contractId]);

  const handleCopy = () => {
    navigator.clipboard.writeText(contract.contract_text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleStageChange = async (stage) => {
    await base44.entities.Contract.update(contract.id, { stage });
    setContract(prev => ({ ...prev, stage }));
  };

  const handleAnalyze = () => {
    setAnalyzing(true);
    sessionStorage.setItem("prefillContractText", contract.contract_text);
    sessionStorage.setItem("prefillContractTitle", contract.title);
    navigate(createPageUrl("Analyze"));
  };

  const handleDownloadTxt = () => {
    const blob = new Blob([contract.contract_text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${(contract.title || "contract").replace(/[^a-zA-Z0-9]/g, "_")}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-16 space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-[400px] rounded-2xl" />
      </div>
    );
  }

  if (!contract) return null;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12 sm:py-16">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <Link
            to={createPageUrl("Pipeline")}
            className="inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-700 mb-3"
          >
            <ArrowLeft className="w-4 h-4" /> Back to Pipeline
          </Link>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">{contract.title}</h1>
          <p className="text-sm text-slate-500 mt-1">
            {contract.party_a_name} & {contract.party_b_name}
            {contract.jurisdiction && ` • ${contract.jurisdiction}`}
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Select value={contract.stage} onValueChange={handleStageChange}>
            <SelectTrigger className="w-44 rounded-xl h-10 border-slate-200">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(stageLabels).map(([k, v]) => (
                <SelectItem key={k} value={k}>{v}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex items-center gap-2 mb-6 flex-wrap">
        <Button variant="outline" onClick={handleCopy} className="rounded-xl">
          {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
          {copied ? "Copied" : "Copy Text"}
        </Button>
        <Button variant="outline" onClick={handleDownloadTxt} className="rounded-xl">
          <Download className="w-4 h-4 mr-2" /> Download .txt
        </Button>
        <Button onClick={handleAnalyze} disabled={analyzing} className="rounded-xl bg-slate-900 hover:bg-slate-800">
          {analyzing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Search className="w-4 h-4 mr-2" />}
          Analyze for Risks
        </Button>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white border border-slate-200 rounded-2xl p-8 sm:p-10"
      >
        <pre className="whitespace-pre-wrap font-sans text-sm text-slate-800 leading-relaxed">
          {contract.contract_text}
        </pre>
      </motion.div>

      <div className="mt-6">
        <SignatureManager
          contract={contract}
          onUpdate={(updates) => setContract(prev => ({ ...prev, ...updates }))}
        />
      </div>

      <div className="mt-8">
        <Disclaimer />
      </div>
    </div>
  );
}