import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowRight, Eye, FileText, ShieldOff } from "lucide-react";
import LoadingAnalysis from "@/components/contract/LoadingAnalysis";
import Disclaimer from "@/components/contract/Disclaimer";
import FileUploader from "@/components/contract/FileUploader";
import RiskBadge from "@/components/contract/RiskBadge";
import MissingProtectionCard from "@/components/contract/MissingProtectionCard";
import VisualDiffRenderer from "@/components/contract/VisualDiffRenderer";
import { motion } from "framer-motion";

export default function VisualDiff() {
  const [originalText, setOriginalText] = useState("");
  const [revisedText, setRevisedText] = useState("");
  const [perspective, setPerspective] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [inputMode, setInputMode] = useState("paste");
  const [viewMode, setViewMode] = useState("visual");

  const handleCompare = async () => {
    if (!originalText.trim() || !revisedText.trim() || !perspective) return;
    setLoading(true);
    setResult(null);

    const perspectiveLabel =
      perspective === "party_a" ? "Party A (offering)" :
      perspective === "party_b" ? "Party B (receiving)" : "neutral observer";

    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an expert contract analyst. Compare these two contract versions from the perspective of ${perspectiveLabel}.

For each meaningful change found, provide:
- change_type: "added", "removed", or "modified"
- section_title: the section/clause name this belongs to
- original_text: exact text from original (empty for additions)
- revised_text: exact text from revised (empty for removals)
- risk_impact: "low", "medium", or "high"
- explanation: brief explanation of how this change affects the user

Also provide:
- overall_risk_score: "low", "medium", or "high" for the revised version
- risk_direction: "increased", "decreased", or "unchanged"
- summary: 2-3 sentence overview of all changes
- stats: count of additions, removals, and modifications
- missing_protections: any new missing protections

ORIGINAL:
"""
${originalText}
"""

REVISED:
"""
${revisedText}
"""`,
      response_json_schema: {
        type: "object",
        properties: {
          overall_risk_score: { type: "string", enum: ["low", "medium", "high"] },
          risk_direction: { type: "string", enum: ["increased", "decreased", "unchanged"] },
          summary: { type: "string" },
          stats: {
            type: "object",
            properties: {
              additions: { type: "number" },
              removals: { type: "number" },
              modifications: { type: "number" },
            },
          },
          changes: {
            type: "array",
            items: {
              type: "object",
              properties: {
                change_type: { type: "string", enum: ["added", "removed", "modified"] },
                section_title: { type: "string" },
                original_text: { type: "string" },
                revised_text: { type: "string" },
                risk_impact: { type: "string", enum: ["low", "medium", "high"] },
                explanation: { type: "string" },
              },
            },
          },
          missing_protections: {
            type: "array",
            items: {
              type: "object",
              properties: {
                title: { type: "string" },
                description: { type: "string" },
              },
            },
          },
        },
      },
    });

    setResult(res);
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-16">
        <LoadingAnalysis />
      </div>
    );
  }

  const directionLabels = {
    increased: { text: "Risk Increased ↑", color: "text-red-700", bg: "bg-red-50", border: "border-red-200" },
    decreased: { text: "Risk Decreased ↓", color: "text-emerald-700", bg: "bg-emerald-50", border: "border-emerald-200" },
    unchanged: { text: "Risk Unchanged →", color: "text-amber-700", bg: "bg-amber-50", border: "border-amber-200" },
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12 sm:py-16">
      <div className="mb-10">
        <div className="flex items-center gap-3 mb-2">
          <Eye className="w-7 h-7 text-slate-400" />
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Visual Diff</h1>
        </div>
        <p className="text-slate-500">Upload two contract versions to see a color-coded visual comparison with risk impact analysis.</p>
      </div>

      {!result ? (
        <div className="space-y-6">
          <div className="flex items-center gap-4">
            <Label className="text-sm font-medium text-slate-700">Input method:</Label>
            <Tabs value={inputMode} onValueChange={setInputMode}>
              <TabsList className="bg-slate-100">
                <TabsTrigger value="paste">Paste Text</TabsTrigger>
                <TabsTrigger value="upload">Upload Files</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <Label className="text-sm font-semibold text-slate-700">Original Version</Label>
              {inputMode === "upload" && <FileUploader onTextExtracted={(t) => setOriginalText(t)} />}
              <Textarea placeholder="Paste original contract..." value={originalText} onChange={(e) => setOriginalText(e.target.value)} className="min-h-[250px] rounded-xl border-slate-200 text-sm resize-y" />
              <p className="text-xs text-slate-400">{originalText.length.toLocaleString()} chars</p>
            </div>
            <div className="space-y-3">
              <Label className="text-sm font-semibold text-slate-700">Revised Version</Label>
              {inputMode === "upload" && <FileUploader onTextExtracted={(t) => setRevisedText(t)} />}
              <Textarea placeholder="Paste revised contract..." value={revisedText} onChange={(e) => setRevisedText(e.target.value)} className="min-h-[250px] rounded-xl border-slate-200 text-sm resize-y" />
              <p className="text-xs text-slate-400">{revisedText.length.toLocaleString()} chars</p>
            </div>
          </div>
          <div className="space-y-2">
            <Label className="text-sm font-medium text-slate-700">Your Perspective</Label>
            <Select value={perspective} onValueChange={setPerspective}>
              <SelectTrigger className="h-12 rounded-xl border-slate-200"><SelectValue placeholder="Select your role" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="party_a">Party A (offering)</SelectItem>
                <SelectItem value="party_b">Party B (receiving)</SelectItem>
                <SelectItem value="neutral">Neutral</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={handleCompare} disabled={!originalText.trim() || !revisedText.trim() || !perspective} className="w-full h-13 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-base font-semibold disabled:opacity-40">
            <Eye className="w-5 h-5 mr-2" /> Run Visual Diff
          </Button>
          <Disclaimer />
        </div>
      ) : (
        <div className="space-y-6">
          <Button variant="outline" onClick={() => setResult(null)} className="rounded-xl">← New Comparison</Button>

          {/* Stats Bar */}
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="bg-white border border-slate-200 rounded-2xl p-6">
            <div className="flex flex-wrap items-center gap-6 mb-4">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">Overall Risk</p>
                <RiskBadge level={result.overall_risk_score} size="lg" />
              </div>
              {result.risk_direction && (
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">Direction</p>
                  <span className={`inline-flex items-center px-4 py-2 rounded-full border font-semibold text-sm ${directionLabels[result.risk_direction]?.bg} ${directionLabels[result.risk_direction]?.border} ${directionLabels[result.risk_direction]?.color}`}>
                    {directionLabels[result.risk_direction]?.text}
                  </span>
                </div>
              )}
              {result.stats && (
                <div className="flex gap-4 ml-auto">
                  <div className="text-center"><p className="text-lg font-bold text-emerald-600">{result.stats.additions || 0}</p><p className="text-xs text-slate-400">Added</p></div>
                  <div className="text-center"><p className="text-lg font-bold text-red-600">{result.stats.removals || 0}</p><p className="text-xs text-slate-400">Removed</p></div>
                  <div className="text-center"><p className="text-lg font-bold text-blue-600">{result.stats.modifications || 0}</p><p className="text-xs text-slate-400">Modified</p></div>
                </div>
              )}
            </div>
            <p className="text-slate-600 leading-relaxed">{result.summary}</p>
          </motion.div>

          {/* View Toggle */}
          <div className="flex items-center gap-3">
            <Tabs value={viewMode} onValueChange={setViewMode}>
              <TabsList className="bg-slate-100">
                <TabsTrigger value="visual">Visual Diff</TabsTrigger>
                <TabsTrigger value="list">Change List</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          {/* Visual Diff View */}
          {viewMode === "visual" && result.changes?.length > 0 && (
            <VisualDiffRenderer changes={result.changes} />
          )}

          {/* List View */}
          {viewMode === "list" && result.changes?.length > 0 && (
            <div className="space-y-3">
              {result.changes.map((change, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }} className={`rounded-xl border p-5 ${
                  change.change_type === "added" ? "bg-emerald-50/50 border-emerald-200" :
                  change.change_type === "removed" ? "bg-red-50/50 border-red-200" :
                  "bg-blue-50/50 border-blue-200"
                }`}>
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div>
                      <span className={`text-xs font-bold uppercase tracking-wider ${
                        change.change_type === "added" ? "text-emerald-600" :
                        change.change_type === "removed" ? "text-red-600" : "text-blue-600"
                      }`}>{change.change_type}</span>
                      <h4 className="font-medium text-sm text-slate-800 mt-0.5">{change.section_title}</h4>
                    </div>
                    <RiskBadge level={change.risk_impact} size="sm" />
                  </div>
                  {change.change_type === "modified" && (
                    <div className="grid sm:grid-cols-2 gap-3 mb-3">
                      <div className="bg-white/70 rounded-lg p-3 border border-red-100">
                        <p className="text-xs font-semibold text-red-400 mb-1">Original</p>
                        <p className="text-xs text-slate-600 leading-relaxed line-through decoration-red-300">{change.original_text}</p>
                      </div>
                      <div className="bg-white/70 rounded-lg p-3 border border-emerald-100">
                        <p className="text-xs font-semibold text-emerald-400 mb-1">Revised</p>
                        <p className="text-xs text-slate-600 leading-relaxed">{change.revised_text}</p>
                      </div>
                    </div>
                  )}
                  {change.change_type === "added" && change.revised_text && (
                    <div className="bg-white/70 rounded-lg p-3 mb-3 border border-emerald-100">
                      <p className="text-xs text-slate-600 leading-relaxed">{change.revised_text}</p>
                    </div>
                  )}
                  {change.change_type === "removed" && change.original_text && (
                    <div className="bg-white/70 rounded-lg p-3 mb-3 border border-red-100">
                      <p className="text-xs text-slate-600 leading-relaxed line-through decoration-red-300">{change.original_text}</p>
                    </div>
                  )}
                  <p className="text-sm text-slate-600">{change.explanation}</p>
                </motion.div>
              ))}
            </div>
          )}

          {result.missing_protections?.length > 0 && (
            <div>
              <div className="flex items-center gap-2.5 mb-4">
                <ShieldOff className="w-5 h-5 text-orange-500" />
                <h2 className="text-lg font-semibold text-slate-900">New Missing Protections</h2>
                <span className="bg-orange-100 text-orange-600 text-xs font-semibold px-2.5 py-0.5 rounded-full">{result.missing_protections.length}</span>
              </div>
              <div className="space-y-3">
                {result.missing_protections.map((p, i) => <MissingProtectionCard key={i} protection={p} index={i} />)}
              </div>
            </div>
          )}

          <Disclaimer />
        </div>
      )}
    </div>
  );
}