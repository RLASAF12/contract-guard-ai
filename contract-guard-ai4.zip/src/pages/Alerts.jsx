import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Bell, AlertTriangle, Info, ShieldAlert, Check, FileText } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

const severityConfig = {
  critical: { icon: ShieldAlert, bg: "bg-red-50", border: "border-red-200", text: "text-red-700", badge: "bg-red-100 text-red-700" },
  warning: { icon: AlertTriangle, bg: "bg-amber-50", border: "border-amber-200", text: "text-amber-700", badge: "bg-amber-100 text-amber-700" },
  info: { icon: Info, bg: "bg-blue-50", border: "border-blue-200", text: "text-blue-700", badge: "bg-blue-100 text-blue-700" },
};

export default function Alerts() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data: alerts = [], isLoading } = useQuery({
    queryKey: ["compliance-alerts"],
    queryFn: () => base44.entities.ComplianceAlert.list("-created_date"),
    initialData: [],
  });

  const markRead = useMutation({
    mutationFn: (id) => base44.entities.ComplianceAlert.update(id, { is_read: true }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["compliance-alerts"] });
      queryClient.invalidateQueries({ queryKey: ["unread-alerts"] });
    },
  });

  const markAllRead = async () => {
    const unread = alerts.filter(a => !a.is_read);
    for (const alert of unread) {
      await base44.entities.ComplianceAlert.update(alert.id, { is_read: true });
    }
    queryClient.invalidateQueries({ queryKey: ["compliance-alerts"] });
    queryClient.invalidateQueries({ queryKey: ["unread-alerts"] });
  };

  const viewAnalysis = async (alert) => {
    if (!alert.is_read) markRead.mutate(alert.id);
    const analyses = await base44.entities.Analysis.filter({ id: alert.analysis_id });
    if (analyses.length > 0) {
      sessionStorage.setItem("contractAnalysis", JSON.stringify(analyses[0]));
      navigate(createPageUrl("Results"));
    }
  };

  const unreadCount = alerts.filter(a => !a.is_read).length;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12 sm:py-16">
      <div className="flex items-center justify-between mb-10">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Compliance Alerts</h1>
          <p className="mt-1 text-slate-500">
            AI-monitored regulatory changes affecting your saved contracts.
          </p>
        </div>
        {unreadCount > 0 && (
          <Button variant="outline" onClick={markAllRead} className="rounded-xl font-semibold">
            <Check className="w-4 h-4 mr-2" />
            Mark All Read
          </Button>
        )}
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[1, 2, 3].map(i => (
            <Skeleton key={i} className="h-24 rounded-xl" />
          ))}
        </div>
      ) : alerts.length === 0 ? (
        <div className="text-center py-24">
          <div className="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center mx-auto mb-5">
            <Bell className="w-7 h-7 text-slate-400" />
          </div>
          <h3 className="text-lg font-semibold text-slate-800 mb-2">No alerts yet</h3>
          <p className="text-slate-500 max-w-sm mx-auto">
            When regulatory changes affect your saved contracts, alerts will appear here.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {alerts.map((alert, i) => {
            const cfg = severityConfig[alert.severity] || severityConfig.info;
            const Icon = cfg.icon;
            let affectedClauses = [];
            try { affectedClauses = JSON.parse(alert.affected_clauses || "[]"); } catch { /* */ }

            return (
              <motion.div
                key={alert.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className={`border rounded-xl p-5 transition-all ${
                  alert.is_read ? "bg-white border-slate-200" : `${cfg.bg} ${cfg.border}`
                }`}
              >
                <div className="flex items-start gap-4">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
                    alert.is_read ? "bg-slate-100" : cfg.badge
                  }`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h3 className={`font-semibold text-sm ${alert.is_read ? "text-slate-600" : "text-slate-900"}`}>
                          {alert.alert_title}
                        </h3>
                        <p className="text-xs text-slate-500 mt-0.5">
                          {alert.contract_title} • {format(new Date(alert.created_date), "MMM d, yyyy")}
                        </p>
                      </div>
                      <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full flex-shrink-0 ${cfg.badge}`}>
                        {alert.severity}
                      </span>
                    </div>
                    <p className={`text-sm mt-2 leading-relaxed ${alert.is_read ? "text-slate-500" : "text-slate-700"}`}>
                      {alert.description}
                    </p>
                    {affectedClauses.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 mt-2">
                        {affectedClauses.map((clause, j) => (
                          <span key={j} className="text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">
                            {clause}
                          </span>
                        ))}
                      </div>
                    )}
                    <div className="flex gap-2 mt-3">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => viewAnalysis(alert)}
                        className="text-xs rounded-lg"
                      >
                        <FileText className="w-3 h-3 mr-1.5" /> View Contract
                      </Button>
                      {!alert.is_read && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => markRead.mutate(alert.id)}
                          className="text-xs rounded-lg text-slate-500"
                        >
                          <Check className="w-3 h-3 mr-1.5" /> Mark Read
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}