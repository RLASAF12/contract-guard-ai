import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import PipelineDashboard from "@/components/pipeline/PipelineDashboard";
import PipelineBoard from "@/components/pipeline/PipelineBoard";

export default function Pipeline() {
  const queryClient = useQueryClient();
  const [workspaceFilter, setWorkspaceFilter] = useState("all");

  const { data: contracts = [], isLoading } = useQuery({
    queryKey: ["contracts"],
    queryFn: () => base44.entities.Contract.list("-created_date"),
    initialData: [],
  });

  const { data: workspaces = [] } = useQuery({
    queryKey: ["workspaces-filter"],
    queryFn: () => base44.entities.Workspace.list("-created_date"),
    initialData: [],
  });

  const filteredContracts = workspaceFilter === "all"
    ? contracts
    : workspaceFilter === "none"
    ? contracts.filter(c => !c.workspace_id)
    : contracts.filter(c => c.workspace_id === workspaceFilter);

  const handleStageChange = async (contractId, newStage) => {
    await base44.entities.Contract.update(contractId, { stage: newStage });
    queryClient.invalidateQueries({ queryKey: ["contracts"] });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 sm:py-16">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Contract Pipeline</h1>
          <p className="mt-1 text-slate-500">Track your contracts through every stage.</p>
        </div>
        <div className="flex items-center gap-2">
          {workspaces.length > 0 && (
            <Select value={workspaceFilter} onValueChange={setWorkspaceFilter}>
              <SelectTrigger className="w-44 rounded-xl h-11 border-slate-200">
                <SelectValue placeholder="All Contracts" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Contracts</SelectItem>
                <SelectItem value="none">No Workspace</SelectItem>
                {workspaces.map(ws => (
                  <SelectItem key={ws.id} value={ws.id}>{ws.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          <Link to={createPageUrl("GenerateContract")}>
            <Button className="bg-slate-900 hover:bg-slate-800 rounded-xl h-11 px-5 font-semibold">
              <Plus className="w-4 h-4 mr-2" /> New Contract
            </Button>
          </Link>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          <Skeleton className="h-32 rounded-2xl" />
          <Skeleton className="h-64 rounded-2xl" />
        </div>
      ) : (
        <>
          <PipelineDashboard contracts={filteredContracts} />
          <PipelineBoard contracts={filteredContracts} onStageChange={handleStageChange} />
        </>
      )}
    </div>
  );
}